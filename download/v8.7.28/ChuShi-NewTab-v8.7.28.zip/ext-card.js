/* == ext-lyric.js (歌词引擎，build 时拼接) == */
/* ============================================================================
 * 「初始」ext-lyric v8.2.8 —— 悬浮卡完全体歌词引擎（纯函数，零 DOM 依赖）
 *
 * v8.2.8 用户实机反馈两连：
 *   ① 歌词延迟补偿（LYR_LAG_MS=100）——「有些逐字歌词明显比唱出来的词
 *      更快」= SMTC position 领先音频输出的系统性差（Windows 共享模式音频
 *      引擎缓冲 + 设备缓冲 ≈ 60-100ms；v8.2.4 高光链路稳定后此差才显形）。
 *      align 入口统一 ms-LYR_LAG_MS：扫光等唱声到位。只影响歌词对齐——
 *      进度条/时间显示走 posNow 不受影响。
 *   ② 末词行尾硬终点律——部分歌曲末词 d 覆盖行内长伴奏（拖尾写进词
 *      时长），唱完后扫光仍缓慢爬（用户观感「非常糟糕」）。末词时长对
 *      行内其他词均长离群（>2.2 倍）时，有效时长压缩到均长 1.8 倍——
 *      伴奏段扫光提前定格挂住；正常歌（含真拖腔 1.5s 内）不触发。
 *
 * 为什么存在：悬浮音乐卡完全体没有「初始」宿主（sandbox.js 核心）在场，
 * 逐字/逐行歌词的解析与对齐必须自带。本文件与 public/sandbox.js 的歌词
 * 解析层 1:1 同语义（parseWordLine/parseWordText/parseLineText/
 * joinTranslation/unitizeLine/alignAt），含 v8.1.4 三律：
 *   ① 伪逐字时长估算律——lrc 行内按显示单元权重估演唱时长
 *      （CJK 字 ~260ms、拉丁词 ~130ms，下限 1.2s、上限行距），不铺满行距；
 *   ② 间奏 lastLine 律——align 落在行间间奏时返回 lastLine（已唱界），
 *      渲染层用它作「已唱界」防回退残留；
 *   ③ 翻译吸附律——ytlrc/tlyric 按最近行起点匹配（逐字窗 800ms/行级 600ms）。
 * 装配律：build-extension.py 把本文件拼在 ext-card.js 之前（内容脚本不支持
 * importScripts）；node 侧经 module.exports 直接单测同一份源码。
 * ==========================================================================*/
(function (root, factory) {
  var api = factory();
  if (root && typeof root === "object") root.ChuShiLyric = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  function clamp(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v; }

  /* ---- 逐字行（yrc）：[start,dur](wStart,wDur,0)词(wStart,wDur,0)词… ---- */
  function parseWordLine(line) {
    var head = /^\s*\[(\d+),(\d+)\]/.exec(line);
    if (!head) return null; /* JSON 版权头行等非时间轴内容一律跳过 */
    var s = +head[1], d = +head[2];
    var marks = [], m;
    var re = /\((\d+),(\d+),\d+\)/g;
    while ((m = re.exec(line))) marks.push({ at: m.index, len: m[0].length, s: +m[1], d: +m[2] });
    if (!marks.length) return null;
    var words = [];
    for (var i = 0; i < marks.length; i++) {
      var from = marks[i].at + marks[i].len;
      var to = i + 1 < marks.length ? marks[i + 1].at : line.length;
      var txt = line.slice(from, to);
      if (txt) words.push({ s: marks[i].s, d: marks[i].d, t: txt });
    }
    if (!words.length) return null;
    return { s: s, e: s + d, t: words.map(function (w) { return w.t; }).join(""), tr: "", w: words };
  }

  function parseWordText(text) {
    var lines = [];
    var rows = String(text || "").split("\n");
    for (var i = 0; i < rows.length; i++) {
      var ln = parseWordLine(rows[i]);
      if (ln) lines.push(ln);
    }
    lines.sort(function (a, b) { return a.s - b.s; });
    return lines;
  }

  /* ---- 行级（lrc）：[mm:ss.xx]文本（多时间戳共享一行文本） ---- */
  function parseLineText(text) {
    var out = [];
    var rows = String(text || "").split("\n");
    for (var i = 0; i < rows.length; i++) {
      var row = rows[i];
      if (!row) continue;
      var times = [], m;
      var re = /\[(\d{1,2}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g;
      while ((m = re.exec(row))) {
        times.push(+m[1] * 60 + +m[2] + (m[3] ? +(m[3] + "000").slice(0, 3) / 1000 : 0));
      }
      if (!times.length) continue;
      var txt = row.slice(row.lastIndexOf("]") + 1).trim();
      for (var t = 0; t < times.length; t++) {
        out.push({ s: Math.round(times[t] * 1000), e: 0, t: txt, tr: "", w: null });
      }
    }
    out.sort(function (a, b) { return a.s - b.s; });
    for (var k = 0; k < out.length; k++) {
      out[k].e = k + 1 < out.length ? out[k + 1].s : out[k].s + 8000;
    }
    /* 去重：同刻同文只留一条 */
    var dedup = [];
    for (var j = 0; j < out.length; j++) {
      var prev = dedup[dedup.length - 1];
      if (prev && prev.s === out[j].s && prev.t === out[j].t) continue;
      dedup.push(out[j]);
    }
    return dedup;
  }

  /* ---- 翻译吸附：按最近行起点匹配（逐字窗 800ms / 行级窗 600ms） ---- */
  function joinTranslation(lines, trText, windowMs) {
    var trs = parseLineText(trText);
    if (!trs.length || !lines.length) return;
    var j = 0;
    for (var i = 0; i < lines.length; i++) {
      while (j + 1 < trs.length && trs[j + 1].s <= lines[i].s) j++;
      var best = -1, bestGap = windowMs;
      for (var k = Math.max(0, j - 2); k < Math.min(trs.length, j + 3); k++) {
        var gap = Math.abs(trs[k].s - lines[i].s);
        if (gap <= bestGap) { bestGap = gap; best = k; }
      }
      if (best >= 0 && trs[best].t) lines[i].tr = trs[best].t;
    }
  }

  /* ---- 行内伪逐字：显示单元切分 + 权重均分（CJK 字×2/拉丁单词×1/空格×0.4） ---- */
  function unitizeLine(ln) {
    if (!ln.t || ln.w) return;
    var toks = [], buf = "", bw = 0;
    function flush() { if (buf) { toks.push({ t: buf, w: bw }); buf = ""; bw = 0; } }
    for (var i = 0; i < ln.t.length; ) {
      var code = ln.t.codePointAt(i) || 0;
      var adv = code > 0xFFFF ? 2 : 1;
      var ch = String.fromCodePoint(code);
      var isCJK = (code >= 0x2E80 && code <= 0x9FFF) || (code >= 0xF900 && code <= 0xFAFF) ||
        (code >= 0x3000 && code <= 0x30FF) || (code >= 0xFF00 && code <= 0xFFEF);
      if (isCJK) { flush(); toks.push({ t: ch, w: 2 }); }
      else if (/\s/.test(ch)) { flush(); toks.push({ t: ch, w: 0.4 }); }
      else { buf += ch; bw += 1; }
      i += adv;
    }
    flush();
    if (!toks.length) return;
    /* v8.1.4 伪逐字时长估算律：不铺满行距（行距含呼吸/间奏）——按显示单元
       权重估演唱时长（CJK ~260ms/字、拉丁 ~130ms/词），下限 1.2s、上限行距 */
    var span = Math.max(400, ln.e - ln.s), sum = 0, j;
    for (j = 0; j < toks.length; j++) sum += toks[j].w;
    var dur = Math.min(span, Math.max(1200, Math.round(sum * 130)));
    var at = ln.s;
    ln.w = [];
    for (j = 0; j < toks.length; j++) {
      var d = dur * toks[j].w / sum;
      ln.w.push({ s: Math.round(at), d: Math.round(d), t: toks[j].t });
      at += d;
    }
  }

  /* ---- 解析入口：yrc 优先（真逐字），lrc 兜底（伪逐字/逐行） ----
     返回 {mode:1, lines, src:"yrc"|"lrc"} | null
     渲染层判定：src==="yrc" 恒逐字；src==="lrc" 逐行（浮窗无强行逐字开关） */
  function parse(ly) {
    if (!ly || typeof ly !== "object") return null;
    var yrcLines = parseWordText(ly.yrc);
    if (yrcLines.length) {
      joinTranslation(yrcLines, ly.ytlrc, 800);
      return { mode: 1, lines: yrcLines, src: "yrc" };
    }
    var lrcLines = parseLineText(ly.lrc);
    if (lrcLines.length) {
      joinTranslation(lrcLines, ly.tlyric, 600);
      for (var u = 0; u < lrcLines.length; u++) unitizeLine(lrcLines[u]);
      return { mode: 1, lines: lrcLines, src: "lrc" };
    }
    return null;
  }

  /* ---- 逐行/逐词二分对齐（sandbox.js alignAt 纯函数版） ----
     返回 {lineIndex, lastLine, wordIndex, wordProgress, lineProgress}
     v8.2.9 行级时钟分离（用户实机反馈「逐行歌词慢了一点，就快一点点」）：
     v8.2.8 的 LYR_LAG_MS=100 是给逐字扫光的（SMTC 领先唱声 ~100ms）——
     但它把行级高亮/滚动也延后了 100ms，逐行模式显慢。现 align 增加第三参
     lineMode：逐行渲染时用原始时基（0ms 补偿，回到行界时序快一拍），
     逐字渲染仍用 -100ms（扫光等唱声）。调用方：ext-card lyricFrame 按
     lyMode 传参；面板走 sandbox.js alignAt 同律。 */
  var LYR_LAG_MS = 100; /* v8.2.8 逐字扫光延迟补偿（SMTC 领先音频输出的固定差） */
  var NONE = { lineIndex: -1, lastLine: -1, wordIndex: -1, wordProgress: 0, lineProgress: 0 };
  function align(data, msRaw, lineMode) {
    if (!data || !data.lines || !data.lines.length) return NONE;
    var ms = lineMode === true ? msRaw : msRaw - LYR_LAG_MS; /* 逐行 0ms / 逐字 -100ms */
    var lines = data.lines;
    var lo = 0, hi = lines.length - 1, idx = -1;
    while (lo <= hi) {
      var mid = (lo + hi) >> 1;
      if (lines[mid].s <= ms) { idx = mid; lo = mid + 1; } else { hi = mid - 1; }
    }
    if (idx < 0) {
      /* 首行预备律：前奏期即定位首行（未唱态），不再等到唱到才跳 */
      return { lineIndex: 0, lastLine: -1, wordIndex: -1, wordProgress: 0, lineProgress: 0 };
    }
    if (ms > lines[idx].e + 200) {
      /* 间奏：携带 lastLine（已唱界）——渲染层防回退残留的真相源 */
      var none = { lineIndex: -1, lastLine: idx, wordIndex: -1, wordProgress: 0, lineProgress: 0 };
      return none;
    }
    var ln = lines[idx];
    var lp = clamp((ms - ln.s) / Math.max(1, ln.e - ln.s), 0, 1);
    if (!ln.w) {
      return { lineIndex: idx, lastLine: -1, wordIndex: -1, wordProgress: 0, lineProgress: lp };
    }
    var ws = ln.w, wi = -1;
    lo = 0; hi = ws.length - 1;
    while (lo <= hi) {
      var mid2 = (lo + hi) >> 1;
      if (ws[mid2].s <= ms) { wi = mid2; lo = mid2 + 1; } else { hi = mid2 - 1; }
    }
    if (wi < 0) {
      return { lineIndex: idx, lastLine: -1, wordIndex: -1, wordProgress: 0, lineProgress: lp };
    }
    var wd = ws[wi];
    var wp = clamp((ms - wd.s) / Math.max(1, wd.d), 0, 1);
    /* v8.2.8 末词行尾硬终点律：末词 d 对行内其他词均长离群（>2.2 倍）=
     * 拖尾被写进词时长（行内长伴奏），压缩有效时长到均长 1.8 倍——
     * 伴奏段扫光提前定格；均长不可得（单词行）或非离群不触发。 */
    if (wi === ws.length - 1 && wp < 1) {
      var avgD = 0, cnt = 0;
      for (var q = 0; q < ws.length - 1; q++) { avgD += ws[q].d; cnt++; }
      avgD = cnt > 0 ? avgD / cnt : 0;
      if (avgD > 0 && wd.d > avgD * 2.2) {
        var wp2 = clamp((ms - wd.s) / Math.max(300, avgD * 1.8), 0, 1);
        if (wp2 > wp) wp = wp2;
      }
    }
    return { lineIndex: idx, lastLine: -1, wordIndex: wi, wordProgress: wp, lineProgress: lp };
  }

  /* ---- 暂停淡入淡出：按当前词剩余时长算一次（部件同管线） ---- */
  function fadeMs(data, ms) {
    if (!data || !data.lines || !data.lines.length) return 260;
    var a = align(data, ms);
    if (a.wordIndex >= 0) {
      var wd = data.lines[a.lineIndex].w[a.wordIndex];
      return clamp(Math.round(wd.s + wd.d - ms), 120, 420);
    }
    if (a.lineIndex >= 0) {
      var ln = data.lines[a.lineIndex];
      return clamp(Math.round(ln.e - ms), 120, 420);
    }
    return 260;
  }

  return {
    clamp: clamp,
    parseWordLine: parseWordLine,
    parseWordText: parseWordText,
    parseLineText: parseLineText,
    joinTranslation: joinTranslation,
    unitizeLine: unitizeLine,
    parse: parse,
    align: align,
    fadeMs: fadeMs,
  };
});

/* == ext-card.js (三态悬浮卡) == */
/* ============================================================================
 * 「初始」ext-card v8.7.17 —— 内容脚本：悬浮音乐卡（置顶所有网页，三态）
 *                          + 全局歌词浮层（桌面歌词同款，v8.7.16 新增）
 *
 * v8.7.17 反馈修订（全局歌词浮层）：①下一句预览退役——第二行改为翻译行
 *   （仅当前句带翻译即外语歌词时显示，灰淡同位，面板 cs-sub 同语言）；
 *   ②中心锚律——行宽变化以歌词中心对称伸缩（dlRecenter 按实测宽差回移
 *   左缘），拖动/持久化语义不变（cardDlyricPos 仍存左缘）。
 * v8.7.16 全局歌词浮层（用户指令：做一个其它音乐播放器同款的全局歌词显示，
 *   像音乐浮窗一样置顶在所有网页上；开关按钮放音乐面板播放控制行
 *   cs-ctl——网易云「词」同位，自绘词徽章图标）：
 *   · 同 Port 双表面：浮层与卡共用 state/tick/lyric 数据面（SW 零改动）；
 *     dlOn=true 时 Port 常开（cardEnabled=false 不断流），applyEnabled/
 *     wake/needFrame/schedule 四处门控放宽为 cardEnabled||dlOn。
 *   · 开关链：面板 kv csDlyric → PresetWidgets 镜像 storage.local.cardDlyric
 *     → onChanged 热跟随；浮层 × 钮反向写 storage → 面板按钮回写。
 *   · 渲染律与完全体歌词同语言（行级时钟分离/--p 扫光/暂停淡出/间奏保持/
 *     无歌词显歌名）；玻璃壳仅 opacity 动画（v8.7.11 杀合成律）。
 *   · 位置持久化 cardDlyricPos，拖动 + resize 钳制，首用底部居中。
 *
 * v8.3.5 用户实机反馈四连（浮窗侧）：
 *   ① 中文歌逐字歌词「重影」——根因：.fw 词壳是 inline 相对定位，
 *      .ov（absolute）的包含块顶 = 字体 em box 顶（content area），
 *      而底字基线由 line box 排布（line-height 1.45 的半 leading 差
 *      ≈3px）→ 两层文本基线错位，中文方块字笔画极敏感 = 重影
 *      （拉丁圆润笔画不敏感，故用户只见中文歌出影）。修：.fw 改
 *      inline-block——包含块成真块盒，内部 line box 与外部行盒基线
 *      对齐律一致（inline-block 基线=末行盒基线），两层像素级重合。
 *      .ov 补 white-space:nowrap 双保险。面板 .cs-w 同律（双表面）。
 *   ② 高光照亮文字（用户：文字层级要比律动高光高）——层叠律：
 *      .glow 是 positioned（z-index:0），同 context 内 positioned
 *      画在非定位内容之上；封面 img 有 z-index:1 压光，但 .meta/.mtm/
 *      .rail/.cap/.flyr/.ftm/.fctl 全是非定位 → 辉光 blur 晕出
 *      （-6px + 10px ≈ 16px）盖住邻近文字。修：全部内容件提层
 *      position:relative;z-index:1（cap/mtm 已 absolute 补 z-index）。
 *      面板 .cs-meta 等同律。
 *   ③ seek 后歌词过快/过慢/要校准——护航窗收窗容差 ±2s 太宽：
 *      真值落点差 1.9s 也直接收窗重锚。修：收窗容差收紧 0.8s +
 *      护航窗 4.5s→3s（真值正常 1~2.5s 内到，过期多=seek 失败，
 *      早收窗早诚实回锚；过期拍走既有中幅软重锚带（|d|≤2.5 →
 *      800ms smoothstep），不再硬跳）。sandbox 同律（收窗/软重锚/dur）。
 *
 * v8.3.4 用户实机反馈四连：
 *   ① 歌词被边框吃掉（用户：很多歌都这样）——长行（多行换行+翻译行）垂直
 *      居中后上下余量不足，行顶/行底侵入 mask 渐隐区甚至被 overflow 硬裁。
 *      容器 118→140px + 渐隐区百分比改固定 18px + 行 padding 3→5px。
 *   ② 标准态/完全态律动高光溢出容器——mini/full 壳 overflow:hidden，
 *      辉光仍在封面四周晕出但被卡片圆角裁住；cover 态保持晕出（设计本意）。
 *   ③ 新歌词切上来「咯噔」——翻译行 display:none↔block 硬切 = 切行瞬间
 *      旧行 -17px / 新行 +17px 布局瞬跳（下方所有行 offsetTop 突变）。
 *      改 grid 0fr↔1fr 高度过渡（布局连续）+ 滚动 target 逐帧追踪
 *      （fsubw 过渡期 offsetHeight 连续变化，追踪窗内每帧重算，收敛终态）+
 *      on 行常驻提层（v8.3.3 只护了 done 行，pending→on 首次提层与
 *      on 过渡结束降层的重栅格化同样产生锐度阶跃）。
 *   ④ 播放/暂停键按下「复位」——乐观窗固定 2500ms 到期强制回落真值，
 *      桥/网易云慢时图标先翻回再翻回 = 字面复位。改真值对齐即退役 +
 *      未对齐顺延（7s 硬上限防桥挂死锁显）。
 *      （面板 music-widget.html 同律四修，「双表面同版」律不破）
 *
 * v8.3.3 用户实机反馈三连：
 *   ① 高光归位（用户：不要给封面加高光，高光就在封面底下；让高光
 *      明显 ≠ 给封面加高光）——封面本体 brightness/saturate/contrast
 *      滤镜退役（v8.2.7「封面提亮」路线废弃），能量全部改走封面背后
 *      的 .glow 层（不透明度增益 0.68→0.85 / 基线 0.28 / scale 0.08，
 *      外圈 -6px blur 10px），光环只从封面四周晕出，封面图恒定不动。
 *   ② 上一句歌词模糊「重置感」双根治：a) done 行常驻合成层
 *      （will-change）——blur/scale 过渡结束的降层重栅格化把合成器
 *      实时模糊换成原生烘焙模糊 = 定住瞬间质感阶跃（像素取证：当前行
 *      边缘能量过渡末 46→71.6 突跳）；b) 行界滞回门——位置源回跳
 *      （SW/桥管线延迟、连续回退放行后软重锚入轨导数变负）让行号
 *      跨界翻转，上一行 done→on→done = blur 取消倒放重演。门律：
 *      前进即时 / 后退与间奏候选持续 650ms 才采纳 / seekGuard 与
 *      硬跟随 300ms 内及位置大跳 2.5s 立即放行（真 seek 零延迟）。
 *   ③ 新标签页焦点归位（用户：新开「初始」不要聚焦网址栏）——见
 *      src/app/page.tsx（挂载短窗 body focus 偷回，type-to-search 接管）。
 *      （面板宿主 sandbox.js 同款滞回门，public/ 真身）
 *
 * v8.3.2 用户实机反馈两连：
 *   ① 歌词高斯模糊景深（用户：未播放/已播放歌词要有高斯模糊）——非当前
 *      行按状态分档模糊（未唱 blur 2px / 已唱 blur 1.1px），当前行 sharp
 *      （blur 0）；filter .45s 同曲线过渡 = 行切换时「聚焦」浮现，与呼吸
 *      缩放叠加成完整景深动效。
 *   ② 歌词动效覆盖双渲染层（用户：要覆盖浮窗和「初始」面板）——v8.3.1
 *      呼吸动效只落了浮窗（面板仍 .55s/.5s 旧时序且无呼吸无模糊，用户
 *      看不到新动效的直接原因）；本版面板 music-widget.html 同步呼吸+
 *      模糊+时序，两渲染层动效语言完全一致。
 *
 * v8.3.1 用户实机反馈六连：
 *   ① 封面 clone 出厂不可见根治（cover→mini「封面没有一镜到底」真凶）：
 *      cloneNode 连内联样式一起走——display 切换（coverEl none）先于克隆，
 *      clone 出厂即 display:none = 封面瞬移全程隐身（录屏实帧取证：暗壳
 *      中间无封面）。covClone 无条件 display:block 拨正。
 *   ② 弹簧克制化（用户：太过了，和「初始」一样就行）——壳弹簧改 dock
 *      standard 同参（420/34，ζ≈0.83，~1% 微过冲）；封面 clone 临界阻尼
 *      （420/41，零过冲——「封面没必要有回弹」）。10% 大过冲读作「复位」
 *      的观感问题随阻尼提升整体消退（三态封面复位 = 弹簧回弹的视觉解读）。
 *   ③ 高光渐入——形变落地辉光 0→满格太突兀：cleanup 归零目标态缓存 +
 *      glowRampAt 起点，paintGlow 按 smoothstep ~480ms 渐入（含提亮/饱和）。
 *   ④ 律动更明显（弱歌隐形根治）——三轴 AGC：峰值跟随天花板（快攻慢放，
 *      地板 0.12），显示值=包络/天花板——《不凡》等低音能量小的曲子被拉
 *      回满幅可见区间；pow 0.85→0.75 + 增益上调（brightness 0.42/glow 0.68）。
 *   ⑤ 歌词动效对齐「初始」完全体（用户视频示例）——当前行 scale 1.06/
 *      邻行 0.94 呼吸过渡，滚动 .55s→.45s，行色 .5s→.35s（入场行滚动途中
 *      即亮）。
 *   ⑥ 壳/封面统一形变时长 D（关键帧自带 offset，WAAPI 拉伸同曲线）——
 *      杜绝两弹簧时长差导致先到者提前 cancel 迟到者。
 *
 * v8.3.0 用户实机反馈两连：
 *   ① 一镜到底动画重做（用户澄清：封面不是不能动——要修的是 v8.2.7 clone
 *      落地的「校准卡顿」；v8.2.9 的「壳变形+封面原地不动+内容长淡入淡出」
 *      读作线性动画且 mini⇄full 有复位感，全部推翻）。三件套：
 *      a) 真弹簧形变——springFrames 采样单位弹簧（k=430/d=26，欠阻尼 ~8%
 *         过冲 = dock 弹簧手感），width/height/left/top/borderRadius 全部按
 *         同一进度轨迹采样成关键帧（WAAPI linear 插样本 = 物理曲线），
 *         cleanup 时样式即终态 = 零校准跳变；
 *      b) 封面连续锚——covClone 从「当前态封面实测矩形」飞到「目标态封面
 *         实测矩形」（两端都 getBoundingClientRect 实测，落地即目标元素
 *         真实布局位 = 校准零误差；v8.2.7 的卡顿真凶是 transform:scale 的
 *         位图缩放与估算终态不重合）；飞行走布局属性（逐帧清晰不拉伸），
 *         落地瞬间 clone 撤、真封面同矩形接管（同帧同位，无接缝）；
 *      c) 内容快交叉——旧壳瞬时让位（新壳同矩形不透明底第 0 帧盖住），
 *         新内容 t+60ms 起级联上浮淡入（dock content-focus 同语言 26ms
 *         级联），收缩方向内容前 32% 淡出；形变期壳 overflow:hidden（内容
 *         生长裁切 = dock 同款），辉光由 clone 携带（裁切不伤光）；真封面
 *         本体延迟到 clone 落地才显形（防双封面同屏）。
 *      附证：cscardin 入场动画改 .boot 类仅首挂载——display:none→block 会
 *         重放 CSS 动画，旧版每次切换都叠一层 0.96→1 缩放 = 「复位感」
 *         真凶之二。
 *   ② 数据面休眠退役（用户指令「不要休眠音乐面板」——切歌后面板留在
 *      上一首）：卡侧不再发 vis 上报，SW 侧 state 轮询的 visCount 门整体
 *      拆除（详见 ext-bg.js）——只要还有卡片 Port 就持续 1Hz 拉真值。
 *      渲染层休眠律（v8.2.6 needFrame）保留：那只管 rAF 绘制帧，state
 *      消息驱动的内容更新从来不在轮询路径上，二者无关。
 *
 * v8.2.9 用户实机反馈五连：
 *   ① 桥响应迟钝浮窗侧配套：无（根修在桥插件 200ms 快排与页面端；本文件只
 *      接频段细化与全局开关）。
 *   ② 逐行歌词快一拍——align 第三参 lineMode：逐行渲染用原始时基（0ms），
 *      逐字扫光保持 -100ms 延迟补偿（v8.2.8 引入的统一延后让逐行显慢）。
 *   ③ 右键隐藏退役（用户指令）——改「初始」面板双开关：
 *      「律动」→ storage.local.cardGlow（默认开，关 = 封面/光晕律动停 +
 *      频谱订阅撤）；「浮窗」→ storage.local.cardEnabled（默认开，关 =
 *      本卡片卸下+断 SW，开启后所有网页显示；全局开关替代按站隐藏）。
 *   ④ 频段细化——specTgt 按 bands.length 自适应：128 段·实际映射（中 9..84
 *      ≈ 250Hz~2kHz / 高 85+ ≈ 2k~16kHz）与旧 16 段两代语义。
 *   ⑤ 三态动画修订（用户：封面都会位移去复位 + 完全体跳一下）：
 *      a) 封面 clone 飞形退役——形变期内容淡出/淡入已掩护封面重排，
 *         封面不再飞行（观感 = 面板壳在变形，封面原地不动）；
 *         b) 跳变根治——旧版切换即 applyPos 按新态宽度 clamp，贴边时新面板
 *         先跳后形变；现形变期钉住源位，left/top 一并动画到夹紧位，
 *         cleanup 才提交 pos。
 * v8.2.8 用户实机反馈五连：
 *   ① 浮窗强行逐字跟随——「初始」面板的强行逐字开关经 NewTab 镜像到
 *      storage.local.cardForceWord（PresetWidgets storageSet 分支，cardAcc
 *      同律），浮窗读取 + onChanged 热跟随；开 = lrc 源走伪逐字
 *      （unitizeLine 词级时间轴已在 parse 生成，只切渲染模式），
 *      yrc 真逐字永不降级。
 *   ② 跳转后歌词对不上（逐行尤严重）根治——间奏滚动跟进：seek 跨间奏
 *      落入时歌词区立即滚到已唱界行（旧版停在旧滚动位直到下一句开始 =
 *      长间奏歌词区完全错位）；transform 写值防抖。
 *   ③ 伴奏期逐字缓慢移动根治——ext-lyric.js 末词行尾硬终点律（词 d 离群
 *      检测压缩）+ LYR_LAG_MS=100 歌词延迟补偿（逐字比唱的快 = SMTC
 *      position 领先音频输出的系统性差，扫光等唱声到位）。
 *   ④ 去方框律——v8.2.7 的 .gring 细节环废弃（用户：方框太丑）；「细节」
 *      的本意 = 律动覆盖高中低音且细腻：三轴全部融入封面 filter
 *      （brightness/saturate/contrast）与辉光本体（opacity/scale 全频段
 *      合成），pow 0.85 非线性提升小信号可见度，分轴攻放（中高频攻快放快
 *      = 跟手，低音慢放 = 鼓点余韵）。
 *   ⑤ 三态切换形变律（dock 面板同语言·一镜到底）——目标面板从源矩形
 *      width/height/borderRadius 布局形变出来（cover→mini 从 56×56 长出、
 *      mini→cover 收缩成 56×56 正方形再无缝接管、mini⇄full 长方形互变），
 *      封面 clone 连续飞形（唯一连续锚），内容形变大半后淡入（不挤压）；
 *      收缩方向旧面板本体承担形变（其壳收缩成封面正方形）。
 *      SW 30Hz + native FFT 40Hz（延迟反馈），包络分轴攻放。
 * v8.2.7 实机反馈三连：
 *   ① 律动变亮律——旧辉光只在封面外圈晕开观感「变暗」；现封面本体随低音
 *      提亮（brightness/saturate 直写，只碰合成器友好属性），辉光上限
 *      0.5→0.85；中频驱动 .gring 细节环（rim light 无模糊，中频段看得清），
 *      高频驱动饱和脉冲——三轴包络（低/中/高）拆自 16 频段原始帧。
 *   ② 封面态 48→56px + 封面态同款律动高光（glow+gring 上身，overflow 放开）。
 *   ③ 三态切换一镜到底——clone 封面从旧态矩形连续飞到新态矩形
 *      （translate+scale），面板同时以「新封面中心」为 transform-origin
 *      长出（展开）/缩回（收进封面），同步开始；中断安全（finish 跳末态），
 *      prefers-reduced-motion / 标签隐藏直切。
 * v8.2.6 性能特供（「5070 卡成屎」根治·渲染休眠律）：
 *   ① rAF 主循环休眠改造——旧版 requestAnimationFrame(loop) 无条件永转，
 *      每个开着网页的前台标签 60fps 永动（Chrome 只暂停后台标签 rAF，
 *      前台标签哪怕浮窗无曲目也全帧跑）。现 needFrame() 判定「还有活干」
 *      才续帧：hidden 立睡 / 无曲目睡 / mini·cover 纯走针降 200ms 定时
 *      节拍（字符串每秒才变一次）/ 辉光衰减尾归零后才睡。
 *   ② visibilitychange 联动——标签切后台：spec off + vis off + sleepNow；
 *      切回：spec on + vis on + wake。后台标签整体撤离频谱链路，
 *      SW specWanted 归零 → 助手零消费者 → v8.2.5 需求门让引擎长眠。
 *   ③ connect() 频谱订阅按可见性初值（hidden 标签不订阅）。
 * v8.2.3 实机反馈四连修：
 *   ① 高光跑封面上根治——.glow（absolute）原来直接盖在静态 img 上 + 被
 *      .cov overflow:hidden 裁成贴脸色块；现 img relative z-index:1 压住
 *      glow、去裁剪，光环像「初始」面板一样从封面四周晕出；
 *   ② 逐字行底色两色调——active 行词底 #b4b4bc（未来#71717a/done#8e8e96/
 *      扫光白四级阶梯），行切换交叉渐隐窗口里当前行恒为视觉主角；
 *   ③ 标准态顶带 30→26px + 带左常显当前时间（红圈「太空」 feedback）；
 *   ④ 主题色跟随「初始」强调色——chrome.storage.local.cardAcc（NewTab
 *      settings.accent 镜像）→ host --acc + onChanged 热跟随，封面占位
 *      渐变 color-mix(--acc)。
 * v8.2.2 实机反馈五连修：
 *   ① 歌词乱跳根治（数据面）——状态真值改为连续锚定：微抖带（≤0.9s）不重锚
 *      （轨迹继续走），中幅偏差（≤2.5s）软重锚 800ms smoothstep 入轨，
 *      更大（seek/切歌）才硬跟随；ne.ts 采样年龄由 ext-bg 透传（同
 *      sandbox.js 恒源钉守/软重锚家族语义，旧版每秒硬换锚 = 锯齿源）。
 *   ② 逐字高光提前消失根治——扫光到 100% 后高光挂住，直到行切换才随
 *      done 渐隐（250ms 自动渐隐废弃）；间奏段同样挂住（自然流入
 *      activeLine===lastLine 不动 DOM），下一句开始才渐灰。
 *   ③ 浮窗任何位置点击都不再跳转「初始」（openPanel 全拆）。
 *   ④ 封面态可拖动：按住拖动（>6px）移窗，单击展开；原生图拖拽 ghost
 *      全面禁止（draggable=false + dragstart 拦截，浮窗与初始面板同律）。
 *   ⑤ 标准态右上钮组独立顶带（与播放/上一首/下一首明确分行）；
 *      写值防抖（词扫光/时间/进度只在变化时写 DOM）。
 *   v8.2.1 三态律保留：封面态（48px 整卡即封面+播放绿点）/标准态
 *   （[收起成封面][放大到完全体]，点进度条→完全体）/完全体（yrc 真逐字
 *   +lrc 逐行+翻译+seek 进度条）；closed Shadow DOM / SW 中继 / 位置持久
 *   / 右键隐藏 / 辉光律动不变。歌词引擎在 ext-lyric.js（build 拼接在前）。
 * ==========================================================================*/

"use strict";

(function () {
  if (window.__chushiCardMounted) return;
  window.__chushiCardMounted = true;

  var HOST_ID = "chushi-card-host";
  if (document.getElementById(HOST_ID)) return;

  /* ---------- v8.2.9 全局开关（面板「浮窗」开关镜像，右键隐藏退役） ----------
     用户指令：取消右键浮窗隐藏；「初始」音乐面板加「浮窗」开关（默认开，
     只要开启浮窗就在所有网页显示）。cardEnabled=false → 本卡卸下 + 断开
     SW（state/spec 轮询需求归零），true → 重连恢复。 */
  var cardEnabled = true;
  var cardBooted = false;
  function initCard() {
    if (cardBooted || !cardEnabled) return;
    cardBooted = true;
    loadPos();
    connect();
    applyPos();
    applyMode();
    /* v8.3.0 入场动画仅首挂载：.boot 类 340ms 后摘除，此后 display 切换
       不再重放 cscardin（复位感真凶之二，见文件头 ①附证） */
    var bootEl = SURFS[mode];
    if (bootEl) {
      bootEl.classList.add("boot");
      setTimeout(function () { bootEl.classList.remove("boot"); }, 340);
    }
    wake();
  }
  /* v8.7.16 门控放宽：Port 是双表面（卡+全局歌词）共用的唯一数据面——
     任一表面在位就保持连接；双关才断流回收（sleepNow+断 Port）。 */
  function applyEnabled() {
    if (!cardEnabled && !dlOn) {
      sleepNow();
      host.style.display = "none";
      dlHide();
      if (port) { try { port.disconnect(); } catch (e0) { /* 已断 */ } port = null; }
      return;
    }
    if (!port) connect();
    if (!cardEnabled) {
      host.style.display = "none";
    } else if (!cardBooted) {
      initCard();
    } else if (track) {
      host.style.display = "block"; applyVis(); wake();
    }
    if (dlOn) { dlBoot(); if (track) dlApplyVis(); }
  }
  /* ---------- v8.2.9 律动总开关（面板「律动」开关镜像） ----------
     cardGlow=false → 三轴包络清零 + 辉光归还样式表 + 频谱订阅撤
     （specWanted 归零 → 引擎零参与，SW 轮询停——性能与开关双收益）。 */
  var glowEnabled = true;
  function specMsgOn() {
    return glowEnabled && document.visibilityState === "visible";
  }
  function applyGlowEnabled() {
    if (!glowEnabled) {
      envB = 0; envM = 0; envH = 0;
      for (var k in COVS) if (COVS[k].on) covClear(COVS[k]);
      lastSpec.on = false;
    }
    try { if (port) port.postMessage({ type: "spec", on: specMsgOn() }); } catch (e0) { /* 断线接管 */ }
    sleepNow(); wake();
  }
  try {
    chrome.storage.local.get(["cardEnabled", "cardGlow"], function (o) {
      if (o) {
        var ve = !(o.cardEnabled === false || o.cardEnabled === "false");
        if (ve !== cardEnabled) cardEnabled = ve;
        var vg = !(o.cardGlow === false || o.cardGlow === "false");
        if (vg !== glowEnabled) glowEnabled = vg;
      }
      initCard(); /* 默认开：直接启动；关：等 onChanged */
    });
    if (chrome.storage.onChanged && chrome.storage.onChanged.addListener) {
      chrome.storage.onChanged.addListener(function (ch, area) {
        if (area !== "local" || !ch) return;
        if (ch.cardEnabled) {
          var v = !(ch.cardEnabled.newValue === false || ch.cardEnabled.newValue === "false");
          if (v !== cardEnabled) { cardEnabled = v; applyEnabled(); }
        }
        if (ch.cardGlow) {
          var g = !(ch.cardGlow.newValue === false || ch.cardGlow.newValue === "false");
          if (g !== glowEnabled) { glowEnabled = g; applyGlowEnabled(); }
        }
      });
    }
  } catch (e) { initCard(); /* 无存储上下文：默认开 */ }

  /* ---------- v8.2.3 主题色跟随「初始」强调色 ----------
     NewTab 页（chrome-extension 页面）把 settings.accent 镜像到
     storage.local.cardAcc（page.tsx）——浮窗任意网页读 storage + onChanged
     热跟随；CSS var(--acc,#8b5cf6) 的 fallback 只在没有「初始」数据时兜底。
     自定义属性不受 :host{all:initial} 影响（all 不作用于 custom props），
     host 级设置可穿透进 shadow 树。 */
  function applyAcc(v) {
    if (typeof v !== "string" || !/^#[0-9a-fA-F]{3,8}$/.test(v)) return;
    host.style.setProperty("--acc", v);
    dlHost.style.setProperty("--acc", v); /* v8.7.16：全局歌词扫光色同跟随 */
  }
  try {
    chrome.storage.local.get(["cardAcc"], function (o) { if (o) applyAcc(o.cardAcc); });
    if (chrome.storage.onChanged && chrome.storage.onChanged.addListener) {
      chrome.storage.onChanged.addListener(function (ch, area) {
        if (area === "local" && ch && ch.cardAcc) applyAcc(ch.cardAcc.newValue);
      });
    }
  } catch (e) { /* 无存储上下文：沿用默认紫 */ }

  /* ---------- v8.2.8 浮窗强行逐字跟随 ----------
     「初始」面板 cs-wbw 开关 → NewTab（PresetWidgets storageSet）镜像到
     storage.local.cardForceWord → 浮窗任意网页读取 + onChanged 热跟随
     （cardAcc 同律镜像）。开 = lrc 源走伪逐字（unitizeLine 词级时间轴
     已在 parse 生成，只切渲染模式）；yrc 真逐字不受开关影响。 */
  var forceWord = false;
  function rebuildForForce() {
    if (ly.parsed) buildLyricDom(); /* lyMode 重判重建 DOM（歌词体已在） */
  }
  try {
    chrome.storage.local.get(["cardForceWord"], function (o) {
      var v = !!(o && (o.cardForceWord === true || o.cardForceWord === "true"));
      if (v !== forceWord) { forceWord = v; rebuildForForce(); }
    });
    if (chrome.storage.onChanged && chrome.storage.onChanged.addListener) {
      chrome.storage.onChanged.addListener(function (ch, area) {
        if (area === "local" && ch && ch.cardForceWord) {
          var v = ch.cardForceWord.newValue === true || ch.cardForceWord.newValue === "true";
          if (v !== forceWord) { forceWord = v; rebuildForForce(); }
        }
      });
    }
  } catch (e) { /* 无存储上下文：跟随面板默认（关） */ }

  /* ---------- v8.7.16 全局歌词浮层（桌面歌词同款·置顶所有网页） ----------
     用户指令：做一个其它音乐播放器同款的全局歌词显示（像音乐浮窗一样
     置顶在所有网页上），开关按钮放音乐面板底部开关行（「歌词」，自绘
     歌词行+音符图标）。
     开关链与浮窗/律动同族：面板 kv csDlyric → 宿主 PresetWidgets 镜像
     chrome.storage.local.cardDlyric → onChanged 热跟随；浮层右上角 × 钮
     反向写 storage → EXT_KV_MAP 回写面板按钮实时翻转（双向同一条链）。
     数据面零新增：与悬浮卡同一 Port（state/tick/lyric 全复用，SW 零
     改动）——dlOn=true 时 Port 常开（cardEnabled=false 也不断流），
     applyEnabled/wake/needFrame 三处门控放宽为 cardEnabled||dlOn。
     渲染律与完全体歌词同语言：ChuShiLyric.align 行级时钟分离（逐行
     原始时基/逐字 -100ms 补偿）、--p clip-path 扫光、暂停整体淡出
     （.pause opacity .38 与 flyrIn 同参）、间奏保持上一句（高光保持律
     同源）、无歌词态显歌名+歌手（桌面歌词同款兜底）。
     逐字扫光可用性与卡同律（dlWordMode = yrc 真逐字 || lrc+强行逐字）。
     默认关（桌面歌词是主动选择的形态）。 */
  var dlOn = false;
  try {
    chrome.storage.local.get(["cardDlyric"], function (o) {
      var v = !!(o && (o.cardDlyric === true || o.cardDlyric === "true"));
      if (v !== dlOn) { dlOn = v; applyDlyric(); }
    });
    if (chrome.storage.onChanged && chrome.storage.onChanged.addListener) {
      chrome.storage.onChanged.addListener(function (ch, area) {
        if (area !== "local" || !ch || !ch.cardDlyric) return;
        var v = ch.cardDlyric.newValue === true || ch.cardDlyric.newValue === "true";
        if (v !== dlOn) { dlOn = v; applyDlyric(); }
      });
    }
  } catch (e) { /* 无存储上下文：默认关 */ }

  var track = null;      /* 最近真值 {title,artist,album,playing,position,duration,rate,pic,songId,fetchedAt} */
  var lastSpec = { on: false, bass: 0, bands: null, t: 0 };
  var envB = 0, envM = 0, envH = 0; /* v8.2.7 律动包络：低/中/高三轴 */
  var glowRampAt = 0;    /* v8.3.1 高光渐入起点（形变 cleanup 时置；0=无 ramp） */
  var pkB = 0, pkM = 0, pkH = 0; /* v8.3.1 AGC 峰值跟随（自适应归一化天花板） */
  var mode = "mini";     /* 三态：cover | mini | full（持久） */
  var optP = false, optAt = 0; /* 播放/暂停乐观翻转窗口 */

  /* ---------- UI（closed Shadow DOM：封面态/标准态/完全体三兄弟） ---------- */
  var host = document.createElement("div");
  host.id = HOST_ID;
  host.style.cssText = "all:initial;position:fixed;z-index:2147483647;left:0;top:0;width:0;height:0;display:none";
  var shadow = host.attachShadow({ mode: "closed" });
  shadow.innerHTML =
    '<style>' +
    ':host{all:initial}' +
    '*{margin:0;padding:0;box-sizing:border-box;font-family:ui-sans-serif,system-ui,"PingFang SC","Microsoft YaHei",sans-serif}' +
    'img{-webkit-user-drag:none;user-select:none}' +
    '@keyframes cscardin{from{opacity:0;transform:scale(.96)}to{opacity:1;transform:scale(1)}}' +
    /* v8.3.0：入场动画只在 .boot（首挂载）——display:none→block 会重放
       CSS 动画，旧版每次三态切换都叠一层 0.96→1 缩放 = 复位感真凶之二 */
    '.surf{position:fixed;border-radius:16px;color:#f4f4f5;user-select:none;touch-action:none;' +
    'background:rgba(28,28,32,.92);border:1px solid rgba(255,255,255,.1);' +
    'box-shadow:0 12px 36px rgba(0,0,0,.35)}' +
    '.surf.boot{animation:cscardin .24s ease}' +
    '.surf.draggable{cursor:grab}.surf.draggable:active{cursor:grabbing}' +
    'button{font-family:inherit}' +
    /* ---- 封面态 ---- */
    '.cover{width:56px;height:56px;border-radius:14px;padding:0;cursor:grab;' +
    'display:none;position:fixed;border:1px solid rgba(255,255,255,.14);' +
    'background:linear-gradient(135deg,color-mix(in srgb,var(--acc,#8b5cf6) 33%,transparent),' +
    'color-mix(in srgb,var(--acc,#8b5cf6) 13%,transparent));touch-action:none}' +
    '.cover:active{cursor:grabbing}' +
    '.cover img{width:100%;height:100%;object-fit:cover;display:block;' +
    'border-radius:inherit;position:relative;z-index:1}' +
    '.cdot{position:absolute;right:4px;bottom:4px;width:7px;height:7px;border-radius:999px;z-index:3;' +
    'background:#34d399;box-shadow:0 0 5px #34d399;display:none}' +
    '.cover.on .cdot{display:block}' +
    /* ---- 通用件 ---- */
    '.row{display:flex;align-items:center;gap:10px}' +
    /* v8.2.3 辉光层叠律：img relative+z-index:1 压住 glow（absolute 无
       z-index 会画在静态 img 上面=「高光跑封面上」）；.cov 去掉
       overflow:hidden（光环要从封面四周晕出去，不是贴脸色块），圆角由
       img inherit 自担 */
    '.cov{position:relative;flex:none;border-radius:10px;' +
    'background:linear-gradient(135deg,color-mix(in srgb,var(--acc,#8b5cf6) 33%,transparent),' +
    'color-mix(in srgb,var(--acc,#8b5cf6) 13%,transparent))}' +
    '.cov img{width:100%;height:100%;object-fit:cover;display:block;' +
    'border-radius:inherit;position:relative;z-index:1}' +
    '.glow{position:absolute;inset:-6px;border-radius:15px;background:var(--acc,#8b5cf6);opacity:0;' +
    'filter:blur(10px);pointer-events:none;z-index:0}' +
    /* v8.2.8 去方框律：.gring 细节环废弃（用户：方框太丑）——中高频
       细节改由辉光本体 opacity/scale 的全频段合成承担（paintGlow） */
    /* v8.3.5 文字层级律：内容件 relative+z-index:1 压住 .glow（positioned
       z-index:0 同 context 画在非定位内容之上 = 辉光晕出盖字）；
       img z-index:1 同带，文字件 DOM 源序靠后同带更高。 */
    '.meta{flex:1;min-width:0;position:relative;z-index:1}' +
    '.t1{font-size:12.5px;font-weight:560;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
    '.t2{font-size:10.5px;color:#a1a1aa;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
    '.b{appearance:none;border:0;background:transparent;color:#a1a1aa;width:30px;height:30px;flex:none;' +
    'display:flex;align-items:center;justify-content:center;border-radius:999px;cursor:pointer;' +
    'transition:color .25s,background-color .25s}' +
    '.b:hover{background:rgba(255,255,255,.1);color:#fff}' +
    '.b.main{width:34px;height:34px;color:#fff;background:var(--acc,#8b5cf6)}' +
    '.b.main:hover{filter:brightness(1.12);background:var(--acc,#8b5cf6)}' +
    '.b svg,.x svg{width:15px;height:15px;fill:none;stroke:currentColor;stroke-width:2;' +
    'stroke-linecap:round;stroke-linejoin:round}' +
    '.b.main svg{width:16px;height:16px;fill:currentColor;stroke:none}' +
    '.x{appearance:none;position:relative;width:22px;height:22px;border-radius:999px;border:0;flex:none;' +
    'background:transparent;color:#8e8e96;display:flex;align-items:center;justify-content:center;' +
    'cursor:pointer;opacity:.8;transition:opacity .2s,color .2s,background-color .2s}' +
    '.x:hover{opacity:1;color:#fff;background:rgba(255,255,255,.1)}' +
    '.x svg{width:12px;height:12px}' +
    '.cap{position:absolute;right:8px;top:8px;display:flex;gap:2px;z-index:1}' +
    '.rail{position:relative;z-index:1;height:10px;display:flex;align-items:center;cursor:pointer}' +
    '.rin{width:100%;height:3px;border-radius:2px;background:rgba(255,255,255,.14);overflow:hidden}' +
    '.fill{display:block;height:100%;width:0%;border-radius:2px;background:var(--acc,#8b5cf6)}' +
    /* ---- 标准态（v8.2.2 钮组独立顶带；v8.2.3 带 30→26px 收敛 + 带左常显时间——
        空带不再空） ---- */
    /* v8.3.4 律动高光防溢出律（用户：标准态和完全态的律动高光不要溢出容器）：
       .glow（inset:-6px + blur 10px + scale≤1.08）的光晕超出卡片圆角边界，
       v8.3.3 辉光增益拉满后更明显——mini/full 壳静态 overflow:hidden，
       辉光仍在封面四周晕出但被卡片圆角裁住；cover 态保持晕出（56px 小方块的
       环绕光晕是设计本意，用户未抱怨）。形变期 style.overflow 临时值 removeProperty
       后自然回落此 CSS 默认，零冲突。 */
    '.card{width:264px;padding:26px 12px 9px;display:none;overflow:hidden}' +
    '.card .cap{top:4px}' +
    '.mtm{position:absolute;left:12px;top:4px;height:22px;line-height:22px;font-size:10px;z-index:1;' +
    'color:#8e8e96;font-variant-numeric:tabular-nums;pointer-events:none}' +
    '.card .cov{width:44px;height:44px}' +
    '.card .rail{margin-top:9px}' +
    /* ---- 完全体 ---- */
    '.fcard{width:324px;padding:14px 16px 12px;border-radius:18px;display:none;overflow:hidden}' +
    '.fcard .cap{top:7px}' +
    '.fcard .row{padding-right:46px}' +
    '.fcard .cov{width:52px;height:52px;border-radius:12px}' +
    '.fcard .t1{font-size:13.5px}.fcard .t2{font-size:11px}' +
    '.ftm{position:relative;z-index:1;display:flex;justify-content:space-between;font-size:10px;color:#8e8e96;margin-top:5px;font-variant-numeric:tabular-nums}' +
    '.fcard .rail{margin-top:2px}' +
    '.fctl{position:relative;z-index:1;display:flex;align-items:center;justify-content:center;gap:22px;margin-top:4px}' +
    /* ---- 歌词（与「初始」部件同渲染律：双层实体色 + clip-path 扫光）----
       v8.3.1 歌词动效对齐「初始」完全体（用户视频示例）：
       · 当前行放大（scale 1.06）/邻行缩小（0.94）——行切换时字号呼吸过渡，
         transform 不参与布局（offsetTop 滚动数学不受影响）；
       · 滚动 .55s→.45s（视频实测 ~400ms ease-out）、行色 .5s→.35s
         （入场行在滚动途中就亮起，不再慢半拍）。
       v8.3.2 高斯模糊景深（用户：未播放/已播放歌词要有高斯模糊）：
       · 未唱行 blur 2px / 已唱行 blur 1.1px / 当前行 sharp——行切换时
         「聚焦」浮现；filter 同曲线 .45s 过渡，与呼吸缩放叠加。 */
    /* v8.3.4 歌词防裁切律（用户：歌词被边框吃掉一部分，很多歌都这样）：
       长行（多行换行+翻译行）垂直居中后上下余量不足，行顶/行底侵入
       mask 渐隐区（旧 16%/84% 百分比≈19px）甚至被 overflow 硬裁——
       容器 118→140px 加高 + 渐隐区改固定 18px（百分比随行高浮动，
       固定 px 与行内容解耦）+ 行 padding 3→5px 呼吸（scale 1.06 后
       顶部余量更足）。 */
    '.flyr{position:relative;z-index:1;height:140px;margin-top:10px;overflow:hidden;flex:none;' +
    '-webkit-mask-image:linear-gradient(180deg,transparent 0,#000 18px,#000 calc(100% - 18px),transparent 100%)}' +
    '/* v8.3.6 歌词左右防裁切律（面板 .cs-lyr-in 同律）：当前行 scale(1.06) 把行盒横向扩出 ≈9px，被 .flyr{overflow:hidden} 左右各切一刀（翻译行首字被吃）；内层左右各留 9px 呼吸位，放大后的行盒仍在视口内。 */' +
    '.flyr-in{position:absolute;left:9px;right:9px;top:0;transition:transform .45s cubic-bezier(.22,1,.36,1),opacity .3s ease;will-change:transform}' +
    '/* v8.3.6 断行兜底：超长不可断词（URL/长英文单词）禁止横向溢出被裁。 */' +
    '.fln{padding:5px 4px;text-align:center;font-size:13.5px;font-weight:560;line-height:1.45;overflow-wrap:anywhere;' +
    'color:#71717a;transform:scale(.94);transform-origin:50% 50%;' +
    'filter:blur(2px);' +
    'transition:color .35s ease,transform .45s cubic-bezier(.22,1,.36,1),filter .45s cubic-bezier(.22,1,.36,1)}' +
    /* v8.3.4 切行防「咯噔」之二【实证反悔律】：on 行提层撤销——任何形式的
       will-change（transform 或 filter）都会把 raster 冻结在切行瞬间的
       .94，1.06 静息显示下整体放大采样模糊（F15b 对照实验：无提层 245 /
       transform 提层 203 / filter 提层 203）。当前行白亮是 v8.2.3 两色调
       律的核心视觉，不可为理论上的 blur 撤层微突跳牺牲；且该突跳方向是
       「聚焦变清晰」（与动效语义一致），非用户所指的咯噔（主因是下方
       翻译行 display 硬切的布局瞬跳，已由 fsubw height 过渡根治）。 */
    '.fln.on{color:#f4f4f5;transform:scale(1.06);filter:blur(0)}' +
    /* v8.3.3 模糊防重置律：done 行常驻合成层——blur/scale 过渡结束的
       降层重栅格化会把「合成器实时模糊」换成「原生烘焙模糊」，上一句
       的模糊在定住瞬间发生质感阶跃（用户：模糊有重置效果）。done 行
       静息 scale .94 与 raster 比例一致，常驻提层零重栅格零阶跃；
       离屏 done 行由 Chrome 自动裁 tile，层成本有界。 */
    '.fln.done{color:#8e8e96;filter:blur(1.1px);will-change:transform,filter}' +
    '.fln.done .fw{color:#8e8e96}' +
    '.fln.done .fw .ov{opacity:0;transition:opacity .6s ease}' +
    '.fln.gap{font-size:11px;letter-spacing:7px;color:#71717a}' +
    /* v8.3.5 逐字重影根治：.fw inline-block 化——inline 相对定位的
       absolute 子元素包含块顶 = em box 顶，与底字 line box 基线差
       半 leading（~3px），中文方块字重影明显。inline-block 后包含
       块=真块盒，内部 line box 与外部行盒基线对齐律一致 → 两层文
       本像素级重合。inline-block 序列在 text-align:center / 断行 /
       基线对齐与 inline 行为一致（createElement 无空白节点无间隙）。 */
    '.fw{position:relative;display:inline-block;color:#71717a}' +
    /* v8.2.3 两色调：当前行未唱词底色提亮（四级阶梯：未来#71717a <
       done#8e8e96 < 当前行#b4b4bc < 扫光#f4f4f5）——行切换 0.6s 交叉
       渐隐窗口里当前行恒为视觉主角，白高光不再「看起来在上一行」 */
    '.fln.on .fw{color:#b4b4bc}' +
    '.fw .ov{position:absolute;left:0;top:0;color:#f4f4f5;pointer-events:none;white-space:nowrap;' +
    'clip-path:inset(-8% calc(100% - var(--p,0%)) -8% 0)}' +
    /* v8.3.4 切行防「咯噔」之一（主因）：翻译行 display:none↔block 硬切——
       切行瞬间旧行高 -17px、新行高 +17px，两处布局无过渡瞬跳 = 「咯噔」。
       改显式 height 过渡：翻译行 nowrap 单行恒高（10.5px×1.5=16px），
       height 0↔16px 平滑插值，布局零跳变（同行收/展同曲线抵消，下方行
       offsetTop 恒定=零扰动）。【实证】grid-template-rows 0fr↔1fr 在本
       环境实测离散跳变（0→17 一步，无中间值）——fr 插值不可信，length
       插值（height）100% 可靠。滚动 target 由 lyricFrame 逐帧追踪
       （lyrTrackUntil）。 */
    '/* v8.3.6 翻译行左右截断根治（面板 .cs-subw 同律）：只声明 grid-template-rows 时隐式列 auto=max-content——nowrap 翻译长句把列撑到卡外再由 overflow:hidden 硬切（左右都被切）。显式 minmax(0,1fr) 锁在卡内 + .fsub overflow:hidden 让 text-overflow:ellipsis 真正生效（截断变省略号）。 */' +
    '.fsubw{display:grid;grid-template-columns:minmax(0,1fr);grid-template-rows:1fr;height:0;opacity:0;overflow:hidden;' +
    'transition:height .38s cubic-bezier(.22,1,.36,1),opacity .38s ease}' +
    '.fln.on .fsubw{height:16px;opacity:1}' +
    '.fsubw .fsub{min-height:0;font-size:10.5px;font-weight:400;color:#a1a1aa;line-height:1.5;' +
    'white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
    '.fempty{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;' +
    'font-size:12px;color:#5b5b63;letter-spacing:2px}' +
    '</style>' +
    /* 封面态 */
    '<button class="cover" id="cover" title="单击展开 · 按住拖动"><span class="glow" id="cglow"></span><img id="cpic" alt="" draggable="false"><span class="cdot" id="cdot"></span></button>' +
    /* 标准态 */
    '<div class="surf card" id="card">' +
    '<span class="mtm" id="mtm">0:00</span>' +
    '<div class="cap">' +
    '<button class="x" id="miniCover" title="收起成封面"><svg viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"/></svg></button>' +
    '<button class="x" id="miniFull" title="放大到完全体（歌词）"><svg viewBox="0 0 24 24"><path d="M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3M8 21H5a2 2 0 0 1-2-2v-3M16 21h3a2 2 0 0 0 2-2v-3"/></svg></button>' +
    '</div>' +
    '<div class="row">' +
    '<div class="cov"><span class="glow" id="glow"></span><img id="pic" alt="" draggable="false"></div>' +
    '<div class="meta"><div class="t1" id="t1">—</div><div class="t2" id="t2"></div></div>' +
    '<button class="b" id="prev" title="上一首"><svg viewBox="0 0 24 24"><path d="M19 20L9 12l10-8v16z"/><path d="M6 5.5v13"/></svg></button>' +
    '<button class="b main" id="play" title="播放 / 暂停"><svg id="icPlay" viewBox="0 0 24 24"><path d="M8 4l12 8-12 8V4z"/></svg><svg id="icPause" viewBox="0 0 24 24" style="display:none"><rect x="6.6" y="4.6" width="3.6" height="14.8" rx="1.3"/><rect x="13.8" y="4.6" width="3.6" height="14.8" rx="1.3"/></svg></button>' +
    '<button class="b" id="next" title="下一首"><svg viewBox="0 0 24 24"><path d="M5 4l10 8-10 8V4z"/><path d="M18 5.5v13"/></svg></button>' +
    '</div>' +
    '<div class="rail" id="rail" title="点按查看歌词（完全体）"><span class="rin"><span class="fill" id="fill"></span></span></div>' +
    '</div>' +
    /* 完全体 */
    '<div class="surf fcard" id="fcard">' +
    '<div class="cap">' +
    '<button class="x" id="fullCover" title="收起成封面"><svg viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"/></svg></button>' +
    '<button class="x" id="fullMini" title="缩回标准卡"><svg viewBox="0 0 24 24"><path d="M8 3v3a2 2 0 0 1-2 2H3M21 8h-3a2 2 0 0 1-2-2V3M3 16h3a2 2 0 0 1 2 2v3M16 21v-3a2 2 0 0 1 2-2h3"/></svg></button>' +
    '</div>' +
    '<div class="row">' +
    '<div class="cov"><span class="glow" id="glow2"></span><img id="fpic" alt="" draggable="false"></div>' +
    '<div class="meta"><div class="t1" id="ft1">—</div><div class="t2" id="ft2"></div></div>' +
    '</div>' +
    '<div class="flyr" id="flyr"><div class="fempty" id="fempty">暂无歌词</div><div class="flyr-in" id="flyrIn"></div></div>' +
    '<div class="ftm"><span id="tcur">0:00</span><span id="tdur">--:--</span></div>' +
    '<div class="rail" id="frail" title="点按跳转播放位置"><span class="rin"><span class="fill" id="ffill"></span></span></div>' +
    '<div class="fctl">' +
    '<button class="b" id="fprev" title="上一首"><svg viewBox="0 0 24 24"><path d="M19 20L9 12l10-8v16z"/><path d="M6 5.5v13"/></svg></button>' +
    '<button class="b main" id="fplay" title="播放 / 暂停"><svg id="ficPlay" viewBox="0 0 24 24"><path d="M8 4l12 8-12 8V4z"/></svg><svg id="ficPause" viewBox="0 0 24 24" style="display:none"><rect x="6.6" y="4.6" width="3.6" height="14.8" rx="1.3"/><rect x="13.8" y="4.6" width="3.6" height="14.8" rx="1.3"/></svg></button>' +
    '<button class="b" id="fnext" title="下一首"><svg viewBox="0 0 24 24"><path d="M5 4l10 8-10 8V4z"/><path d="M18 5.5v13"/></svg></button>' +
    '</div>' +
    '</div>';

  (document.body || document.documentElement).appendChild(host);
  /* 原生图拖拽 ghost 全面禁止（v8.2.2：初始面板与浮窗同律——拖窗口时
     封面被浏览器当 img 拖走的鬼影是「封面没禁拖」的真身） */
  host.addEventListener("dragstart", function (e) { e.preventDefault(); });

  function el(id) { return shadow.getElementById(id); }
  var coverEl = el("cover"), cpic = el("cpic"), cdot = el("cdot");
  var card = el("card"), pic = el("pic"), glow = el("glow");
  var fcard = el("fcard"), fpic = el("fpic"), glow2 = el("glow2");
  var cglow = el("cglow");
  var t1 = el("t1"), t2 = el("t2"), ft1 = el("ft1"), ft2 = el("ft2");
  var fill = el("fill"), ffill = el("ffill");
  var icPlay = el("icPlay"), icPause = el("icPause");
  var ficPlay = el("ficPlay"), ficPause = el("ficPause");
  var flyrIn = el("flyrIn"), fempty = el("fempty"), tcur = el("tcur"), tdur = el("tdur");
  var mtm = el("mtm");

  var SURFS = { cover: coverEl, mini: card, full: fcard };
  var WIDTH = { cover: 56, mini: 264, full: 324 };

  /* ---------- v8.4.11 滚轮归属：指针在小窗上时不再带动宿主页面滚动 ----------
   * 卡片自身没有内部滚动面（歌词自动跟唱，进度条走指针拖动），悬在卡片上
   * 滚轮唯一的效果就是滚走底下的网页（closed shadow 也不拦 wheel 冒泡）。
   * 三面壳上捕获段拦截（passive:false 才能 preventDefault）；Ctrl+滚轮
   * 放行——那是页面缩放手势，不属于「滚动页面」。 */
  function swallowWheel(el) {
    if (!el) return;
    el.addEventListener(
      "wheel",
      function (e) {
        if (e.ctrlKey) return;
        e.preventDefault();
        e.stopPropagation();
      },
      { passive: false, capture: true }
    );
  }
  for (var surfKey in SURFS) swallowWheel(SURFS[surfKey]);

  /* ---------- 位置：三态共用，拖动 + 持久 + 按当前态宽度钳制 ---------- */
  var pos = { x: Math.max(12, (window.innerWidth || 1200) - 296), y: 76 };
  function loadPos() {
    try {
      chrome.storage.local.get(["cardPos", "cardMode", "cardPill"], function (o) {
        if (o && o.cardPos && typeof o.cardPos.x === "number") pos = o.cardPos;
        /* v8.2.1 迁移：旧「药丸收起」用户 → 封面态（药丸已退役） */
        if (o && o.cardMode && SURFS[o.cardMode]) mode = o.cardMode;
        else if (o && o.cardPill) mode = "cover";
        applyPos(); applyMode();
      });
    } catch (e) { applyPos(); applyMode(); }
  }
  function savePos() {
    try { chrome.storage.local.set({ cardPos: pos, cardMode: mode }); } catch (e) { /* 隐私模式等 */ }
  }
  function clampPos() {
    var w = window.innerWidth || 1200, h = window.innerHeight || 800;
    var mw = WIDTH[mode] || 264;
    pos.x = Math.min(Math.max(8, pos.x), Math.max(8, w - mw - 8));
    pos.y = Math.min(Math.max(8, pos.y), h - 56);
  }
  function applyPos() {
    clampPos();
    for (var k in SURFS) {
      SURFS[k].style.left = pos.x + "px";
      SURFS[k].style.top = pos.y + "px";
    }
  }

  function applyMode() {
    for (var k in SURFS) {
      SURFS[k].style.display = k === mode ? "block" : "none";
      SURFS[k].style.overflow = ""; /* v8.3.0 安全网：形变期裁切绝不跨态残留 */
    }
    applyPos(); applyVis(); applyDraggable();
  }
  var RM = !!(window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches);
  var trans = null;
  function covUnitOf(m) { return COVS[m]; }
  function finishTrans() {
    if (!trans) return;
    var t = trans; trans = null;
    for (var i = 0; i < t.anims.length; i++) { try { t.anims[i].finish(); } catch (e1) { /* 已结束 */ } }
    t.cleanup();
  }
  function plainSetMode(m) {
    mode = m; lastTcur = ""; /* 强制下一帧重写 tcur/mtm——防态切换残留旧串 */
    savePos(); applyMode();
  }
  /* ---------- 三态几何（v8.3.0 实测律） ---------- */
  function rectOf(surf) {
    var r = surf.getBoundingClientRect();
    return { left: r.left, top: r.top, width: r.width, height: r.height,
      br: parseFloat(getComputedStyle(surf).borderRadius) || 16 };
  }
  /* 封面矩形实测：cover 态本体即封面；mini/full 取壳内 .cov。
     两端全部实测（不估算）= clone 落地必与目标元素真实布局位重合
     （v8.2.7「校准卡顿」根治：估算终态 ≠ 真实布局位）。 */
  function covRectOf(surf) {
    var c = surf === coverEl ? surf : surf.querySelector(".cov");
    if (!c) return null;
    var r = c.getBoundingClientRect();
    return { left: r.left, top: r.top, width: r.width, height: r.height,
      br: parseFloat(getComputedStyle(c).borderRadius) || 10, el: c };
  }
  /* ---------- 真弹簧采样（v8.3.1 克制化：与「初始」dock 面板切换同族） ----------
     用户实机反馈：ζ≈0.58 的 ~10% 过冲「太过了」+ 封面回弹读作「复位」。
     现壳弹簧 = dock standard 同参（stiffness 420 / damping 34，framer 同族
     ζ≈0.83，过冲 ~1%——与「初始」面板切换手感一致，克制不 Q 弹）；
     封面 clone 弹簧 = 临界阻尼（420/41，ζ≈1.0，零过冲——封面没必要回弹）。
     每样本 4 子步积分（dt=1/240）防数值阻尼吃掉曲线；各形变属性共用同一
     进度轨迹（线性伸缩同一 ODE 解），样本间 WAAPI linear 插值 = 物理曲线。
     cleanup 时样式即终态，零校准跳变。 */
  var SPRING = [420, 34];        /* 壳：dock standard 同参（~1% 微过冲） */
  var SPRING_COVER = [420, 41];  /* 封面：临界阻尼（零过冲） */
  function springFrames(k, d) {
    var dt = 1 / 240, x = 0, v = 0, out = [], i, j;
    for (i = 0; i < 96; i++) {
      for (j = 0; j < 4; j++) {
        v += (-k * (x - 1) - d * v) * dt;
        x += v * dt;
      }
      out.push(x);
      if (Math.abs(x - 1) < 0.0015 && Math.abs(v) < 0.0045) break;
    }
    return out;
  }
  function morphFrames(fr, to, spr) {
    var ss = springFrames(spr ? spr[0] : SPRING[0], spr ? spr[1] : SPRING[1]), n = ss.length, kfs = [];
    kfs.push({ left: fr.left + "px", top: fr.top + "px", width: fr.width + "px",
      height: fr.height + "px", borderRadius: fr.br + "px", offset: 0 });
    for (var i = 0; i < n; i++) {
      var s = ss[i];
      kfs.push({
        left: (fr.left + (to.left - fr.left) * s) + "px",
        top: (fr.top + (to.top - fr.top) * s) + "px",
        width: (fr.width + (to.width - fr.width) * s) + "px",
        height: (fr.height + (to.height - fr.height) * s) + "px",
        borderRadius: (fr.br + (to.br - fr.br) * s) + "px",
        offset: (i + 1) / n
      });
    }
    return { kfs: kfs, dur: Math.max(220, Math.round(n * 1000 / 60)) };
  }
  /* 封面连续锚 clone：源封面 wrapper 原位克隆（cloneNode 带走辉光/律动
     内联样式与 img），fixed 定位按实测矩形飞行（布局属性动画 = 逐帧清晰
     不拉伸），pointer 穿透、置于最顶。
     v8.3.1 关键修复：cloneNode 会连内联样式一起带走——cover→mini/full 方向
     display 切换（coverEl style.display="none"）先于本函数执行，clone 出厂
     即 display:none = 封面瞬移、全程不可见（录屏实帧：暗壳中间无封面）。
     此处无条件 display:block 拨正，三方向 clone 恒可见。 */
  function covClone(fromRect) {
    var c = fromRect.el.cloneNode(true);
    var ids = c.querySelectorAll("[id]");
    for (var i = 0; i < ids.length; i++) ids[i].removeAttribute("id");
    c.style.cssText += ";display:block;position:fixed;margin:0;pointer-events:none;z-index:2147483000;" +
      "left:" + fromRect.left + "px;top:" + fromRect.top + "px;" +
      "width:" + fromRect.width + "px;height:" + fromRect.height + "px;" +
      "border-radius:" + fromRect.br + "px;";
    shadow.appendChild(c);
    return c;
  }
  /* ---------- 三态切换（v8.3.0 一镜到底·真弹簧·封面连续锚） ----------
     收缩（→cover）：旧壳本体弹簧收缩成 56×56（内容前 32% 淡出），封面
     clone 从旧封面矩形飞向同终点，cleanup 封面态无缝接管。
     展开/互变：目标壳从源矩形弹簧长出（width/height/left/top/borderRadius
     同轨迹，贴边时位置一并滑入夹紧位），内容 t+60ms 级联上浮淡入（dock
     content-focus 同语言），封面 clone 飞向目标封面实测矩形、落地时真封面
     才显形（防双封面同屏）。中断安全：finish 跳末态再起。 */
  function setMode(m) {
    if (!SURFS[m] || m === mode) return;
    finishTrans();
    if (RM || document.visibilityState !== "visible") { plainSetMode(m); wake(); return; }
    var from = mode;
    var fromSurf = SURFS[from], toSurf = SURFS[m];
    var sfr = rectOf(fromSurf);
    if (sfr.width < 4) { plainSetMode(m); wake(); return; }
    /* 先克隆（带走实时律动内联样式），再清源辉光（克隆体不受影响） */
    var covFrom = covRectOf(fromSurf);
    if (covUnitOf(from)) covClear(covUnitOf(from));
    mode = m; lastTcur = "";
    savePos();
    var vw = window.innerWidth || 1200, vh = window.innerHeight || 800;
    var tw = WIDTH[m] || 264;
    var toX = Math.min(Math.max(8, pos.x), Math.max(8, vw - tw - 8));
    var toY = Math.min(Math.max(8, pos.y), vh - 56);
    var collapsing = m === "cover";
    var surfAnim = collapsing ? fromSurf : toSurf;
    var toRect, covTo, clone = null, cloneImg = null;
    if (collapsing) {
      /* 收缩终点 = 封面态本体（56×56 圆角 14，位置即夹紧位）——确定性矩形 */
      toRect = { left: toX, top: toY, width: 56, height: 56, br: 14 };
      covTo = { left: toX, top: toY, width: 56, height: 56, br: 14 };
    } else {
      for (var k1 in SURFS) SURFS[k1].style.display = k1 === m ? "block" : "none";
      applyVis(); applyDraggable();
      /* 目标壳先按终局位隐身实测（自然尺寸 + 真实封面布局位），同任务内
         起动画，无中间帧外泄 */
      toSurf.style.left = toX + "px";
      toSurf.style.top = toY + "px";
      toSurf.style.visibility = "hidden";
      var str = rectOf(toSurf);
      covTo = covRectOf(toSurf);
      toSurf.style.visibility = "";
      if (str.width < 4 || !covTo) { plainSetMode(m); wake(); return; }
      toRect = { left: toX, top: toY, width: str.width, height: str.height, br: str.br };
    }
    var mf = morphFrames(
      { left: sfr.left, top: sfr.top, width: sfr.width, height: sfr.height, br: sfr.br },
      toRect);
    var D = mf.dur;
    var anims = [], kids = [];
    fromSurf.style.pointerEvents = "none";
    /* v8.3.0：目标壳保持可点（中断律——形变中再点切换钮 = finish 跳末态
       再起新形变；拖动被 WAAPI forwards 压住、cleanup 提交夹紧位，无害） */
    surfAnim.style.overflow = "hidden"; /* 形变期裁切内容生长（dock 同款）；辉光由 clone 携带 */
    /* ① 壳真弹簧形变（v8.3.1：克制 dock standard 弹簧） */
    anims.push(surfAnim.animate(mf.kfs, { duration: D, easing: "linear", fill: "forwards" }));
    /* ② 封面连续锚：实测矩形 → 实测矩形（临界阻尼零回弹，与壳同步开始）。
       v8.3.1：壳/封面统一时长 D——两套关键帧各自带 offset 0..1，WAAPI 按
       D 拉伸同曲线，杜绝「先到者 onfinish 提前 cancel 迟到者」的截断风险 */
    if (covFrom) {
      clone = covClone(covFrom);
      cloneImg = clone.querySelector ? clone.querySelector("img") : null;
      var cf = morphFrames(
        { left: covFrom.left, top: covFrom.top, width: covFrom.width,
          height: covFrom.height, br: covFrom.br },
        { left: covTo.left, top: covTo.top, width: covTo.width,
          height: covTo.height, br: covTo.br }, SPRING_COVER);
      if (cf.dur > D) D = cf.dur;
      anims.push(clone.animate(cf.kfs, { duration: D, easing: "linear", fill: "forwards" }));
      anims[0].effect.updateTiming({ duration: D }); /* 壳随 D 对齐（同曲线拉伸） */
    }
    /* ③ 内容交叉：收缩 = 前 32% 快淡出；展开/互变 = 级联上浮淡入；
       真封面本体延迟到 clone 落地才显形 */
    var hostK = collapsing ? fromSurf : toSurf;
    var kidsK = hostK.children;
    for (var i2 = 0; i2 < kidsK.length; i2++) {
      kids.push(collapsing
        ? kidsK[i2].animate([{ opacity: 1 }, { opacity: 0 }],
            { duration: Math.round(D * 0.32), easing: "ease-in", fill: "forwards" })
        : kidsK[i2].animate(
            [{ opacity: 0, transform: "translateY(7px)" },
             { opacity: 1, transform: "translateY(0px)" }],
            { duration: 230, delay: 60 + i2 * 26,
              easing: "cubic-bezier(.22,1,.36,1)", fill: "backwards" }));
    }
    if (!collapsing && covTo.el && covTo.el !== toSurf) {
      kids.push(covTo.el.animate([{ opacity: 0 }, { opacity: 1 }],
        { duration: 150, delay: Math.max(0, D - 170), easing: "ease-out", fill: "backwards" }));
    }
    trans = { anims: anims, kids: kids, clone: clone, cloneImg: cloneImg,
      cleanup: function () {
        for (var i3 = 0; i3 < anims.length; i3++) { try { anims[i3].cancel(); } catch (e2) { /* 已结束 */ } }
        for (var i4 = 0; i4 < kids.length; i4++) { try { kids[i4].cancel(); } catch (e3) { /* 已结束 */ } }
        if (clone && clone.parentNode) clone.parentNode.removeChild(clone);
        pos.x = toX; pos.y = toY; /* 形变终点即夹紧位：提交后 applyPos 零位移 */
        fromSurf.style.pointerEvents = "";
        toSurf.style.pointerEvents = "";
        surfAnim.style.overflow = "";
        /* v8.3.1 高光渐入：形变期 clone 携带的是清零辉光（covClear 后克隆），
           形变途中 paintGlow 又把目标态包络值写进了真封面（当时不可见，
           写值缓存被占）——落地瞬间辉光 0→满格 = 「突兀」。现 cleanup 把
           目标态缓存归零 + 记 ramp 起点，paintGlow 按 easeRamp 因子从
           中性渐入（~480ms），高光跟着形变落地温柔浮现。 */
        if (COVS[m]) { covClear(COVS[m]); }
        glowRampAt = Date.now();
        if (mode === m) plainSetMode(m);
        wake();
      } };
    for (var a2 = 0; a2 < anims.length; a2++) anims[a2].onfinish = finishTrans;
    wake(); /* v8.2.6 态切换接管：循环若在睡（如 cover 静置）按新态需求重估 */
  }
  function applyDraggable() {
    card.classList.toggle("draggable", mode === "mini");
    fcard.classList.toggle("draggable", mode === "full");
  }

  /* ---------- 拖动 / 点击 ----------
     把手 = 卡片主体空白（meta 区 + padding）+ 封面态整卡（按住拖动）；
     按钮、进度条、歌词区、标准/完全体封面一律不启动拖动。
     封面态：单击展开 / 按住拖动（拖后拦误触 click）。 */
  var drag = { on: 0, moved: 0, px: 0, py: 0, ox: 0, oy: 0, surf: null };
  function dragHandleOK(e) {
    if (e.button !== undefined && e.button !== 0) return false;
    var t = e.target;
    if (t.closest && t.closest("button, .cov, .rail, .flyr")) return false;
    return true;
  }
  function dragStart(e, surf) {
    drag.on = 1; drag.moved = 0;
    drag.px = e.clientX; drag.py = e.clientY;
    drag.ox = pos.x; drag.oy = pos.y;
    drag.surf = surf;
    try { surf.setPointerCapture(e.pointerId); } catch (e1) { /* 已释放 */ }
  }
  function onDown(e) {
    if (!dragHandleOK(e)) return;
    dragStart(e, e.currentTarget);
  }
  function onMove(e) {
    if (!drag.on) return;
    var dx = e.clientX - drag.px, dy = e.clientY - drag.py;
    if (Math.abs(dx) + Math.abs(dy) > 4) drag.moved = 1;
    if (drag.moved) {
      pos.x = drag.ox + dx; pos.y = drag.oy + dy;
      applyPos();
    }
  }
  var coverClickBlock = 0;
  function onUp() {
    if (drag.on && drag.moved) {
      savePos();
      if (drag.surf === coverEl) coverClickBlock = Date.now(); /* 拖后拦截误触 click */
    }
    drag.on = 0;
    wake(); /* v8.2.6 拖动结束保险（进度/走针接续） */
  }
  card.addEventListener("pointerdown", onDown);
  card.addEventListener("pointermove", onMove);
  card.addEventListener("pointerup", onUp);
  card.addEventListener("pointercancel", function () { drag.on = 0; });
  fcard.addEventListener("pointerdown", onDown);
  fcard.addEventListener("pointermove", onMove);
  fcard.addEventListener("pointerup", onUp);
  fcard.addEventListener("pointercancel", function () { drag.on = 0; });
  /* 封面态：整卡即把手——按住拖动移窗，单击展开（拖动后 350ms 内的
     click 是拖动误触，拦截） */
  coverEl.addEventListener("pointerdown", function (e) {
    if (e.button !== undefined && e.button !== 0) return;
    dragStart(e, coverEl);
  });
  coverEl.addEventListener("pointermove", onMove);
  coverEl.addEventListener("pointerup", onUp);
  coverEl.addEventListener("pointercancel", function () { drag.on = 0; });
  /* v8.2.2 用户律：浮窗任何位置点击都不跳转「初始」——主体点击无操作 */

  /* ---------- v8.7.16 全局歌词浮层 UI（独立 closed shadow，与卡共数据面） ----------
     玻璃×动画杀合成律（v8.7.11 遗产）：backdrop-filter 元素自身只允许
     opacity 动画（dlin 入场仅 opacity；暂停淡出走 transition opacity），
     零 transform/filter 动画挂玻璃壳。
     位置持久化 cardDlyricPos；首用无存档时视口底部居中（桌面歌词惯例位）。
     v8.7.17 中心锚律：行宽变化（切行/翻译行有无）以药丸中心对称伸缩——
     dlRecenter 在内容重建后实测新宽，把左缘回移宽度差之半，视觉=固定
     中心向两边长缩（修复「长度变化后像位移了」）；cardDlyricPos 仍存
     左缘（旧存档零迁移），拖动语义不变。基线 dlLastW 首测只记录不回移
     （有存档用户首帧不跳位），dlHide 归零重臂（下次显示重新基线）。
     拖动=pointer 全家桶（卡同族），× 钮写 cardDlyric=false → onChanged
     双向链（浮层隐 + 面板按钮回写）。 */
  var dlHost = document.createElement("div");
  dlHost.id = "chushi-dlyric-host";
  dlHost.style.cssText = "all:initial;position:fixed;z-index:2147483647;left:0;top:0;width:0;height:0;display:none";
  var dlShadow = dlHost.attachShadow({ mode: "closed" });
  dlShadow.innerHTML =
    '<style>' +
    ':host{all:initial}' +
    '*{margin:0;padding:0;box-sizing:border-box;font-family:ui-sans-serif,system-ui,"PingFang SC","Microsoft YaHei",sans-serif}' +
    '@keyframes dlin{from{opacity:0}to{opacity:1}}' +
    /* v8.7.21 切行模糊过渡：行内容重建即重播（remove+reflow+add，wpulse
       同律）——blur(7px)→0 + 淡入；挂在 .dl1/.dl2 子元素（玻璃律只禁
       玻璃壳自身 transform/filter，子元素动画不碰磨砂采样链）。 */
    '@keyframes dlswap{0%{opacity:0;filter:blur(7px)}100%{opacity:1;filter:blur(0)}}' +
    '.dl1.lin,.dl2.lin{animation:dlswap .42s ease}' +
    /* 显隐唯一开关律：药丸本体不带 display:none（v8.7.16 visual 实测坑：
       宿主 block 而药丸 display:none = 文本在 DOM 但零绘制）——宿主
       dlHost.style.display 是唯一显隐面，药丸随宿主现隐。 */
    '.dl{position:fixed;max-width:min(720px,94vw);padding:9px 20px 10px;border-radius:16px;' +
    'text-align:center;cursor:grab;user-select:none;touch-action:none;' +
    'background:rgba(22,22,28,.78);border:1px solid rgba(255,255,255,.12);' +
    'box-shadow:0 10px 34px rgba(0,0,0,.4);backdrop-filter:blur(18px) saturate(1.35);' +
    '-webkit-backdrop-filter:blur(18px) saturate(1.35);' +
    /* v8.7.21 玻璃拉伸律：width/left 双过渡同曲线同拍——行宽变化时磨砂
       玻璃拉伸/收缩、左缘同拍回移=视觉中心逐帧恒定（center=left+width/2
       的 e(t) 系数相消可证）。布局动画不在「玻璃×动画杀合成律」禁域
       （该律只禁 transform/filter；高度盒同族先例=PanelStage 玻璃卡满窗）。
       .dl.drag 拖动态只留 opacity 过渡（跟手不果冻）。 */
    'transition:opacity .3s ease,width .45s cubic-bezier(.22,1,.36,1),' +
    'left .45s cubic-bezier(.22,1,.36,1)}' +
    '.dl.drag{transition:opacity .3s ease}' +
    '.dl:active{cursor:grabbing}' +
    '.dl.boot{animation:dlin .26s ease}' +
    '.dl.pause{opacity:.38}' +
    '.dl1{font-size:21px;font-weight:650;line-height:1.45;color:#fff;white-space:nowrap;overflow:hidden;' +
    'text-overflow:ellipsis;text-shadow:0 1px 7px rgba(0,0,0,.38)}' +
    /* v8.7.20 逐字白描边根修（用户：播放过的高亮字有白色描边）：
       旧律=白底字上叠 accent 扫光层——accent 字形抗锯齿边缘混入底下纯白，
       已唱字四周白晕读作「描边」（悬浮卡/面板无此病：其底色是灰阶，白晕对比弱）。
       根修=层角色对调：底层恒 accent（已唱色）、面层白字裁「未唱区」
       （clip 左缘=--p，右半显白）——已唱字形直接坐在深色药丸上零白晕；
       未唱白字边缘的 accent 混色在人眼跟踪焦点（已唱区）之外不可察。
       视觉语义不变：未唱白 / 已唱 accent；--p 量化/行级时钟零改动。 */
    '.dl1 .dw{position:relative;display:inline-block;color:var(--acc,#8b5cf6)}' +
    '.dl1 .dw .ov{position:absolute;left:0;top:0;pointer-events:none;white-space:nowrap;color:#fff;' +
    'clip-path:inset(-8% -8% -8% var(--p,0%))}' +
    '.dl2{margin-top:1px;font-size:12.5px;font-weight:450;line-height:1.5;color:rgba(255,255,255,.55);' +
    'white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
    '.dlx{appearance:none;position:absolute;top:-9px;right:-9px;width:22px;height:22px;border-radius:999px;' +
    'border:1px solid rgba(255,255,255,.16);background:rgba(45,45,52,.95);color:#e4e4e7;display:none;' +
    'align-items:center;justify-content:center;cursor:pointer;padding:0}' +
    '.dl:hover .dlx{display:flex}' +
    '.dlx:hover{background:#52525b;color:#fff}' +
    '.dlx svg{width:10px;height:10px;stroke:currentColor;fill:none;stroke-width:2.6;stroke-linecap:round}' +
    '@media (prefers-reduced-motion:reduce){.dl.boot{animation:none}.dl{transition:none}' +
    '.dl1.lin,.dl2.lin{animation:none}}' +
    '</style>' +
    '<div class="dl" id="dlPill">' +
    '<button class="dlx" id="dlX" title="隐藏全局歌词（可在「初始」音乐面板重新开启）">' +
    '<svg viewBox="0 0 24 24"><path d="M5 5l14 14M19 5L5 19"/></svg></button>' +
    '<div class="dl1" id="dlL1"></div>' +
    '<div class="dl2" id="dlL2"></div>' +
    '</div>';
  (document.body || document.documentElement).appendChild(dlHost);
  dlHost.addEventListener("dragstart", function (e) { e.preventDefault(); });
  var dlPill = dlShadow.getElementById("dlPill");
  var dlL1 = dlShadow.getElementById("dlL1");
  var dlL2 = dlShadow.getElementById("dlL2");
  swallowWheel(dlPill); /* 悬停浮层不滚走底页（卡同律 v8.4.11） */

  var dlPos = null, dlPosSaved = false, dlBooted = false;
  var dlLineIdx = -2, dlWant = "", dlWordMode = false, dlNoLyr = false;
  var dlPrevPlaying = null, dlWords = [], dlLast1 = "", dlLast2 = "";
  var dlLastW = 0; /* v8.7.17 中心锚基线：0=未基线（首测只记录不回移） */
  function dlClamp() {
    var w = window.innerWidth || 1200, h = window.innerHeight || 800;
    /* v8.7.21 显式宽度优先：width 过渡飞行中 offsetWidth 是中间值，
       钳制按目标宽算（style.width 恒为目标 px），未显式化老态兜底旧路 */
    var pw = parseFloat(dlPill.style.width) || dlPill.offsetWidth || 420,
        ph = dlPill.offsetHeight || 76;
    dlPos.x = Math.min(Math.max(8, dlPos.x), Math.max(8, w - pw - 8));
    dlPos.y = Math.min(Math.max(8, dlPos.y), Math.max(8, h - ph - 8));
  }
  function dlApplyPos() {
    if (!dlPos) return; /* v8.7.17 竞态护栏：dlLoadPos 存储回调落地前 state 真值
      可能先到（v8.7.16 潜伏竞态，dlClamp dlPos.x 崩=浮层失去定位；诊断
      diag-dlpage 实锤）。回调落地后 dlLoadPos 会补一次 dlApplyPos 定位。 */
    dlClamp();
    dlPill.style.left = dlPos.x + "px";
    dlPill.style.top = dlPos.y + "px";
  }
  /* v8.7.17 中心锚律：内容重建（切行/翻译行有无）后调用——实测新宽，
     左缘回移宽度差之半 = 中心不动；越界钳制仍由 dlApplyPos 兑底。 */
  /* v8.7.21 玻璃拉伸律：内容重建后实测自然宽（Range 取文本布局宽——
     overflow/ellipsis 是绘制期裁剪不改布局，过渡飞行中读数不受污染；
     scrollWidth≥clientWidth 读不出收缩目标故弃用），显式写 width=拉伸/
     收缩动画源；左缘同拍回移差半=中心锚（已存档用户）。
     首用未存档（!dlPosSaved，用户没拖过）改真居中：x=(视口-新宽)/2，
     修复「无歌词药丸态不居中」——旧律 dlLoadPos 异步回调晚到时首用居中
     被 dlLastW 记账吞掉（首测只记录不回移），x 停在假设宽位=视觉偏侧。 */
  function dlMeasure() {
    function natW(el) {
      try {
        var r = document.createRange();
        r.selectNodeContents(el);
        return r.getBoundingClientRect().width || 0;
      } catch (eM) { return 0; }
    }
    /* 左右 padding 40 + 边框 2（box-sizing:border-box） */
    var raw = Math.max(natW(dlL1), natW(dlL2)) + 42;
    var vw = window.innerWidth || 1200;
    return Math.max(60, Math.min(Math.round(raw), Math.min(720, Math.round(vw * 0.94))));
  }
  function dlRecenter() {
    if (!dlPos) return;
    var nw = dlMeasure();
    if (nw) {
      dlPill.style.width = nw + "px";
      if (!dlPosSaved) {
        /* 首用真居中：内容宽度变化始终对齐视口中心（拖走后 dlPosSaved=true 转中心锚） */
        dlPos.x = Math.round(((window.innerWidth || 1200) - nw) / 2);
      } else if (dlLastW && nw !== dlLastW) {
        dlPos.x -= Math.round((nw - dlLastW) / 2);
      }
      dlLastW = nw;
    }
    dlApplyPos();
  }
  function dlLoadPos() {
    try {
      chrome.storage.local.get(["cardDlyricPos"], function (o) {
        if (o && o.cardDlyricPos && typeof o.cardDlyricPos.x === "number") {
          dlPos = { x: o.cardDlyricPos.x, y: o.cardDlyricPos.y };
          dlPosSaved = true;
        } else {
          /* 首用默认位：底部居中（显示时按实测宽再精调一次） */
          var w = window.innerWidth || 1200, h = window.innerHeight || 800;
          /* v8.7.21 默认位假设宽 460→42（空药丸实宽）：dlRecenter 首用真
             居中接手前，空药丸首帧即居中，消除内容到达前的偏侧闪帧 */
          dlPos = { x: Math.round((w - 42) / 2), y: Math.max(8, h - 176) };
          dlPosSaved = false;
        }
        if (dlBooted) dlApplyPos();
      });
    } catch (e) { dlPos = { x: 360, y: 600 }; if (dlBooted) dlApplyPos(); }
  }
  function dlSavePos() {
    try { chrome.storage.local.set({ cardDlyricPos: dlPos }); } catch (e) { /* 隐私模式等 */ }
  }
  function dlBoot() {
    if (dlBooted || !dlOn) return;
    dlBooted = true;
    dlLoadPos();
    dlPill.classList.add("boot");
    setTimeout(function () { dlPill.classList.remove("boot"); }, 320);
  }
  function dlHide() {
    if (dlBooted) dlSavePos();
    dlBooted = false;
    dlLastW = 0; /* 中心锚基线归零：下次显示重新基线（v8.7.17） */
    dlPill.classList.remove("boot");
    dlHost.style.display = "none";
  }
  function dlApplyVis() {
    if (!dlOn) return;
    /* 无真值不空挂（诚实边界：hub 不在场就隐没，绝不伪造内容） */
    dlHost.style.display = track ? "block" : "none";
    if (track) {
      /* 首用无存档：按实测宽底部居中一次（桌面歌词惯例位）；只做一次
         （dlLastW=0 时），此后中心锚归 dlRecenter 所有——state 轮询
         反复进入本函数不再重摆（避免与中心锚互相打架）。 */
      if (!dlPosSaved && dlPos && !dlLastW) {
        dlPos.x = Math.round(((window.innerWidth || 1200) - dlPill.offsetWidth) / 2);
        dlLastW = dlPill.offsetWidth || 0; /* 空药丸基线：首句展开仍围绕视口中心 */
      }
      dlApplyPos();
    }
  }
  function applyDlyric() {
    if (dlOn) { dlBoot(); if (!port) connect(); if (track) dlApplyVis(); wake(); }
    else dlHide();
  }
  /* ---------- 浮层渲染（行切换重建 + 词扫光 + 暂停淡出） ----------
     v8.7.17：第二行=翻译行（dlSetSub）——仅当前句带 ln.tr（外语歌词
     才有翻译吸附，ext-lyric joinTranslation 已合入）时显示；下一句
     预览（dlNextText）退役（用户指令：不用下一句预览灰淡）。 */
  function dlSetSub(t) {
    var s = t || "";
    if (s !== dlLast2) { dlLast2 = s; dlL2.textContent = s; }
  }
  /* v8.7.21 切行模糊过渡重播口：remove+reflow+add（连行必重播，wpulse 同律） */
  function dlSwapFx() {
    dlL1.classList.remove("lin");
    dlL2.classList.remove("lin");
    void dlL1.offsetWidth;
    dlL1.classList.add("lin");
    dlL2.classList.add("lin");
  }
  function dlBuildLine(ln) {
    dlWords = [];
    dlL1.innerHTML = "";
    dlLast1 = "";
    if (dlWordMode && ln && ln.w && ln.w.length) {
      for (var i = 0; i < ln.w.length; i++) {
        var sp = document.createElement("span");
        sp.className = "dw";
        sp.appendChild(document.createTextNode(ln.w[i].t));
        var ov = document.createElement("span");
        ov.className = "ov";
        ov.appendChild(document.createTextNode(ln.w[i].t));
        sp.appendChild(ov);
        dlL1.appendChild(sp);
        dlWords.push({ ov: ov, p: -1 });
      }
    } else {
      dlL1.textContent = (ln && ln.t) || "·";
    }
    dlSetSub(ln && ln.tr);
    dlSwapFx();
  }
  function dlSweep(n) {
    for (var j = 0; j < dlWords.length; j++) {
      var pp = j < n.wordIndex ? 1 : j > n.wordIndex ? 0 : (n.wordIndex >= 0 ? n.wordProgress : 0);
      var q = Math.round(pp * 400) / 400; /* 0.25% 量化：不变不写（卡同律） */
      if (dlWords[j].p !== q) {
        dlWords[j].p = q;
        dlWords[j].ov.style.setProperty("--p", (q * 100).toFixed(2) + "%");
      }
    }
  }
  function dlFrame() {
    if (!dlOn) return;
    var playing = effPlaying();
    if (playing !== dlPrevPlaying) {
      dlPrevPlaying = playing;
      dlPill.classList.toggle("pause", !playing && !!track);
    }
    if (!track) return;
    var p = ly.parsed;
    if (!p || !p.lines || !p.lines.length) {
      /* 无歌词态：歌名 + 歌手（桌面歌词同款兜底），切歌跟随 */
      var t1s = "♪ " + (track.title || "未知曲目"), t2s = track.artist || "";
      if (t1s !== dlLast1 || t2s !== dlLast2) {
        dlNoLyr = true; dlWordMode = false; dlLineIdx = -2; dlWords = [];
        dlL1.innerHTML = ""; dlLast1 = t1s; dlL1.textContent = t1s;
        dlSetSub(t2s);
        dlSwapFx();
        dlRecenter(); /* 行宽变化 → 拉伸动画+中心重排（v8.7.21） */
      }
      return;
    }
    if (dlNoLyr) { dlNoLyr = false; dlLineIdx = -2; dlLast1 = ""; }
    /* 歌词键跟踪：切歌/强行逐字重建（buildLyricDom 重判）后行号重置 */
    if (dlWant !== ly.want) {
      dlWant = ly.want;
      dlLineIdx = -2; dlLast1 = "";
      dlWordMode = p.src === "yrc" || (p.src === "lrc" && forceWord);
    }
    /* 行级时钟分离（卡同律）：词模式 -100ms 唱声补偿，行模式原始时基 */
    var n = ChuShiLyric.align(p, posNow() * 1000, !dlWordMode);
    if (n.lineIndex === -1) {
      /* 间奏：保持上一句不动（高光保持律同源；v8.7.17 预览退役，
         翻译行随上一句自然驻留，不主动换内容） */
      return;
    }
    if (n.lineIndex !== dlLineIdx) {
      dlLineIdx = n.lineIndex;
      dlBuildLine(p.lines[n.lineIndex]);
      dlRecenter(); /* 行宽变化 → 拉伸动画+中心重排（长行不越界，v8.7.21） */
    } else if (dlWordMode) {
      dlSweep(n);
    }
  }
  /* ---------- 浮层拖动 + × 隐藏 ---------- */
  var dlDrag = { on: 0, moved: 0, px: 0, py: 0, ox: 0, oy: 0 };
  dlPill.addEventListener("pointerdown", function (e) {
    if (e.button !== undefined && e.button !== 0) return;
    if (e.target && e.target.closest && e.target.closest(".dlx")) return;
    dlDrag.on = 1; dlDrag.moved = 0;
    dlPill.classList.add("drag"); /* v8.7.21 拖动期过渡归零（跟手不果冻） */
    dlDrag.px = e.clientX; dlDrag.py = e.clientY;
    dlDrag.ox = dlPos ? dlPos.x : 0; dlDrag.oy = dlPos ? dlPos.y : 0;
    try { dlPill.setPointerCapture(e.pointerId); } catch (e1) { /* 已释放 */ }
  });
  dlPill.addEventListener("pointermove", function (e) {
    if (!dlDrag.on || !dlPos) return;
    var dx = e.clientX - dlDrag.px, dy = e.clientY - dlDrag.py;
    if (Math.abs(dx) + Math.abs(dy) > 4) dlDrag.moved = 1;
    if (dlDrag.moved) { dlPos.x = dlDrag.ox + dx; dlPos.y = dlDrag.oy + dy; dlApplyPos(); }
  });
  dlPill.addEventListener("pointerup", function () {
    if (dlDrag.on && dlDrag.moved) { dlPosSaved = true; dlSavePos(); }
    dlDrag.on = 0;
    dlPill.classList.remove("drag");
  });
  dlPill.addEventListener("pointercancel", function () { dlDrag.on = 0; dlPill.classList.remove("drag"); });
  window.addEventListener("resize", function () { if (dlOn && dlPos && dlBooted) dlApplyPos(); });
  dlShadow.getElementById("dlX").addEventListener("click", function () {
    dlOn = false;
    dlHide();
    try { chrome.storage.local.set({ cardDlyric: false }); } catch (e) { /* 无存储 */ }
    /* onChanged 链接管面板按钮回写（PresetWidgets EXT_KV_MAP 反向同步） */
  });

  /* ---------- SW 通道（断线重连 + 保活） ---------- */
  var port = null;
  var cmdSeq = 0;
  var pingTimer = null;

  function connect() {
    if (port) return;
    try {
      port = chrome.runtime.connect({ name: "chushi-card" });
    } catch (e) {
      port = null; /* 扩展上下文失效（更新中） */
      return;
    }
    port.onMessage.addListener(onMsg);
    port.onDisconnect.addListener(function () {
      port = null;
      setTimeout(function () { if (!port) connect(); }, 1200);
    });
    if (!pingTimer) {
      pingTimer = setInterval(function () {
        if (document.visibilityState !== "visible") return;
        try { if (port) port.postMessage({ type: "ping" }); } catch (e) { /* 断线事件接管 */ }
      }, 10000);
    }
    /* v8.3.0：vis 上报退役（数据面休眠拆除，见文件头 ②）——state 轮询
       不再依赖可见性；频谱订阅仍按 specMsgOn()（可见 + 律动开）初值。
       hidden 标签不订阅频谱（specWanted=0 → 引擎零参与）照旧。 */
    try {
      port.postMessage({ type: "spec", on: specMsgOn() });
    } catch (e) { /* 断线事件接管 */ }
  }

  function send(cmd, position) {
    return new Promise(function (resolve) {
      if (!port) { resolve(false); return; }
      var id = ++cmdSeq;
      try {
        port.postMessage({ type: "cmd", cmd: cmd, position: position, id: id });
        port.__cmdResolve = port.__cmdResolve || {};
        port.__cmdResolve[id] = function (ok) {
          /* v8.2.2 seek 乐观重锚 + 护航窗：进度条即时到位，真值收敛前
             陈旧拍不回弹（sandbox.js v8.0.9 同律） */
          if (ok && cmd === "seek" && typeof position === "number" && track) {
            track.position = Math.max(0, position);
            track.fetchedAt = Date.now();
            softA = null;
            seekGuard = { to: position, at: Date.now() };
            backStreak = 0;
          }
          resolve(ok === true);
        };
        setTimeout(function () {
          if (port && port.__cmdResolve && port.__cmdResolve[id]) {
            delete port.__cmdResolve[id]; resolve(false);
          }
        }, 4000);
      } catch (e) { resolve(false); }
    });
  }

  /* v8.2.2：openPanel 已拆——浮窗零跳转「初始」（用户明确不要） */

  function onMsg(m) {
    if (!m || typeof m !== "object") return;
    if (m.type === "state") {
      var nt = m.track && typeof m.track === "object" ? m.track : null;
      if (nt && !(nt.fetchedAt > 0)) nt.fetchedAt = m.at || Date.now();
      ingestTrack(nt);
      renderStatic();
      /* v8.7.16：全局歌词会话（cardEnabled=false）下不得点亮卡片壳 */
      if (cardEnabled) host.style.display = "block";
      applyVis();
      if (dlOn) dlApplyVis(); /* v8.7.16：真值到达驱动浮层显隐（首装会话路径） */
      lyricTick(); /* 切歌检测（want 变化时内部自重建） */
      wake(); /* v8.2.6 真值到达：循环若在睡（无曲目期）此处唤醒 */
    } else if (m.type === "spec") {
      lastSpec = { on: m.on === true, bass: Number(m.bass) || 0,
        bands: Array.isArray(m.bands) ? m.bands : null, t: Date.now() };
      if (lastSpec.on) wake(); /* v8.2.6 频谱活动帧：辉光包络需要帧 */
    } else if (m.type === "cmdOk" && m.id) {
      var r = port && port.__cmdResolve && port.__cmdResolve[m.id];
      if (r) { delete port.__cmdResolve[m.id]; r(m.ok); }
    } else if (m.type === "lyric") {
      onLyricMsg(m);
    }
  }

  /* ---------- 渲染 ---------- */
  function renderStatic() {
    if (!track) return;
    t1.textContent = track.title || "—";
    t2.textContent = track.artist || "";
    ft1.textContent = track.title || "—";
    ft2.textContent = track.artist || "";
    var src = track.pic || "";
    if (src) {
      if (pic.getAttribute("src") !== src) pic.setAttribute("src", src);
      if (fpic.getAttribute("src") !== src) fpic.setAttribute("src", src);
      if (cpic.getAttribute("src") !== src) cpic.setAttribute("src", src);
      /* v8.3.0 形变途中的切歌热跟随：飞行中的封面 clone 同步换图
         （克隆体不接 state 广播，不补这行 = 落地瞬间旧图闪一帧） */
      if (trans && trans.cloneImg && trans.cloneImg.getAttribute("src") !== src) {
        trans.cloneImg.setAttribute("src", src);
      }
    }
    applyVis();
  }

  /* v8.3.4 播放键「复位」根治（用户：暂停/播放键按下时会有复位）：旧乐观窗
     固定 2500ms 到期强制回落真值——桥/网易云慢时（SW 轮询最坏 ~2s 才拿到
     新真值，窗口余量极小）图标先翻回旧态再等真值翻回来 = 字面上的复位。
     新律：真值对齐即退役；未对齐期间持续显示用户点击的方向（顺延），
     7s 硬上限防桥挂死永久锁显。 */
  var OPT_MAX = 7000;
  function effPlaying() {
    if (optAt) {
      var aligned = !!track && track.playing === optP;
      if (aligned || Date.now() - optAt >= OPT_MAX) optAt = 0;
      else return optP;
    }
    return !!(track && track.playing);
  }

  function applyVis() {
    var has = !!track;
    coverEl.classList.toggle("on", effPlaying());
    icPlay.style.display = effPlaying() ? "none" : "block";
    icPause.style.display = effPlaying() ? "block" : "none";
    ficPlay.style.display = effPlaying() ? "none" : "block";
    ficPause.style.display = effPlaying() ? "block" : "none";
    /* v8.7.16：cardEnabled=false 时 host 恒隐（全局歌词会话Port仍在，
       state 真值照达——不能让关了浮窗的卡被真值到达重新点亮） */
    if (has && cardEnabled && host.style.display !== "block") host.style.display = "block";
  }

  /* ---------- 位置插值：锚点轨迹 + 软重锚（sandbox.js 同族语义） ----------
     baseNowOf = 锚点真值轨迹；posNowOf = 软窗混合后的显示位置。
     v8.2.2 锯齿根治：真值到达时按偏差分带仲裁——微抖带不重锚（轨迹
     继续走），中幅软重锚平滑入轨，大幅（seek/切歌）硬跟随。 */
  var softA = null;         /* 软重锚窗 {from,at,dur} */
  function baseNowOf(t) {
    if (!t) return 0;
    var rate = t.rate > 0 ? t.rate : 1;
    var p = t.position + (t.playing ? ((Date.now() - t.fetchedAt) / 1000) * rate : 0);
    if (t.duration > 0) return Math.min(t.duration, Math.max(0, p));
    return Math.max(0, p);
  }
  function posNowOf(t) {
    var p = baseNowOf(t);
    if (softA) {
      var el = Date.now() - softA.at;
      if (el >= softA.dur) { softA = null; return p; }
      var rate = t && t.rate > 0 ? t.rate : 1;
      var fromP = softA.from + (el / 1000) * rate * (t && t.playing ? 1 : 0);
      var k = el / softA.dur;
      k = k * k * (3 - 2 * k);
      var out = fromP + (p - fromP) * k;
      if (t && t.duration > 0) return Math.min(t.duration, Math.max(0, out));
      return Math.max(0, out);
    }
    return p;
  }
  function posNow() { return posNowOf(track); }

  /* 真值进入仲裁（v8.2.2 乱跳根治核心，sandbox.js 同族管线精简移植）：
     ① 微噪声 |d|≤2.5s 一律 800ms smoothstep 软重锚——显示从当前位置平滑
        入轨（连续、可收敛）；>2.5s（seek/切歌级）硬跟随。
     ② 回退熔断：播放中单记回退拍（-0.3~-2.5s）拒收（旧锚继续走），
        连续 2 记 = 真回退源才放行——上游锚点年龄抖动的回跳到不了显示层。
     ③ seek 护航窗（4.5s）：拖动后乐观重锚到目标，护航期内远离目标的
        陈旧拍拒收、真值到目标 ±2s 即收窗——进度条回弹同根治。 */
  var backStreak = 0;
  var seekGuard = null;    /* {to, at} */
  function ingestTrack(nt) {
    var now = Date.now();
    var old = track;
    if (!nt) { track = null; softA = null; seekGuard = null; return; }
    if (!old) { track = nt; softA = null; return; }
    var sameSong = (nt.songId || 0) === (old.songId || 0) &&
      (nt.title || "") === (old.title || "") &&
      Math.abs((nt.duration || 0) - (old.duration || 0)) < 1.5;
    if (!sameSong) { track = nt; softA = null; seekGuard = null; backStreak = 0; return; }
    if (nt.playing !== old.playing) { track = nt; softA = null; seekGuard = null; backStreak = 0; return; }
    var disp = posNowOf(old);
    var rate = nt.rate > 0 ? nt.rate : 1;
    var age = nt.playing ? Math.min(6, Math.max(0, (now - nt.fetchedAt) / 1000)) : 0;
    var implied = nt.position + age * rate;
    /* seek 护航窗：拖动已乐观重锚——远离目标的拍是拖动前旧轨/中间态。
       v8.3.5：收窗容差 2→0.8（真值落点差 1~2s 也收窗 = 误差带内重锚，
       体感「seek 后歌词要校准」）；窗 4.5→3s（真值正常 1~2.5s 内到，
       过期多=seek 失败，早收窗早诚实回锚；过期拍走下方中幅软重锚带
       （|d|≤2.5 → 800ms smoothstep），不再硬跳）。 */
    if (seekGuard) {
      if (now - seekGuard.at > 3000) { seekGuard = null; }
      else if (Math.abs(implied - seekGuard.to) <= 0.8) { seekGuard = null; }
      else return; /* 陈旧拍：忽略，目标轨迹继续走 */
    }
    var d = implied - disp;
    /* 回退熔断（仅播放稳态）：单记回退拒收，连续 2 记放行 */
    if (nt.playing && d < -0.3 && d > -2.5) {
      backStreak++;
      if (backStreak < 2) return;   /* 拒收：旧锚继续走 */
    } else {
      backStreak = 0;
    }
    if (d >= -2.5 && d <= 2.5) {
      softA = { from: disp, at: now, dur: 800 };
      track = nt;
      return;
    }
    track = nt; softA = null;       /* 大偏差：诚实硬跟随 */
    lastHardAt = now;               /* v8.3.3 行界滞回门的 seek 级旁路信号 */
  }
  var lastHardAt = 0;               /* 最近一次硬跟随时刻（门 300ms 内放行） */

  function fmt(s) {
    s = Math.floor(s || 0);
    var m = Math.floor(s / 60), r = s % 60;
    return m + ":" + (r < 10 ? "0" : "") + r;
  }

  /* ---------- 歌词：请求（SW 代理）+ 归属强校验 + 有限重试 ---------- */
  var ly = { want: "", tries: 0, done: "", busy: false, raw: null, parsed: null };
  function lyricTick() {
    if (!track) return;
    var want = track.songId ? String(track.songId) : (track.title ? "t:" + track.title : "");
    if (want !== ly.want) {
      ly.want = want; ly.tries = 0; ly.done = ""; ly.busy = false;
      ly.raw = null; ly.parsed = null;
      buildLyricDom();
    }
    if (!want || ly.busy || ly.done === want) return;
    ly.busy = true;
    try {
      port.postMessage({ type: "lyric", songId: track.songId ? String(track.songId) : "", title: track.title || "", key: want });
    } catch (e) { ly.busy = false; return; }
    /* 4s 无回包：释放 BUSY 位 + 走统一重试律（2.5s 间隔，防打爆） */
    setTimeout(function () { if (ly.busy) { ly.busy = false; lyRetry(); } }, 4000);
  }
  function onLyricMsg(m) {
    ly.busy = false;
    var want = ly.want;
    if (!want || m.key !== want) return; /* 曲目已切走（latest-wins） */
    if (m.ok && m.lyric && typeof m.lyric === "object" &&
        (String(m.lyric.yrc || "").trim() || String(m.lyric.lrc || "").trim())) {
      /* 归属强校验：hub /api/lyric 是单槽缓存，切歌窗口内返回的必然是
         上一首歌词——songId 不符一律视为未就绪（smtc.ts 同款最终防线） */
      var wantId = /^(\d+)$/.test(want) ? Number(want) : 0;
      var gotId = Number(m.lyric.songId) || 0;
      if (wantId && gotId && gotId !== wantId) { lyRetry(); return; }
      ly.done = want;
      ly.tries = 0;
      ly.raw = m.lyric;
      ly.parsed = ChuShiLyric.parse(m.lyric);
      buildLyricDom();
    } else {
      lyRetry();
    }
  }
  function lyRetry() {
    ly.tries++;
    if (ly.tries <= 5) {
      setTimeout(function () { if (ly.want && ly.done !== ly.want) lyricTick(); }, 2500);
    } else {
      ly.done = ly.want; /* 有限重试耗尽：本轮放弃（切歌重来） */
      buildLyricDom();
    }
  }

  /* ---------- 歌词 DOM 构建（歌词键 + 解析对象双判定才重建） ---------- */
  var lineEls = [];      /* [{el, words:[{ov,p}], sung, clean}] */
  var activeLine = -2;
  var lastLyrTy = null;  /* v8.2.8 歌词滚动写值防抖（间奏分支每帧进） */
  var lyMode = 0;        /* 1=逐字扫光（真 yrc）；0=逐行高亮 */
  var prevLyrPlaying = null;
  function buildLyricDom() {
    var p = ly.parsed;
    lineEls = []; activeLine = -2; prevLyrPlaying = null; lastLyrTy = null; lyrTrackUntil = 0; lyrTrackIdx = -1;
    flyrIn.innerHTML = "";
    flyrIn.style.transform = "translateY(0px)";
    if (!p || !p.lines || !p.lines.length) {
      fempty.style.display = "flex";
      lyMode = 0;
      return;
    }
    fempty.style.display = "none";
    /* 浮窗判定律（v8.2.8）：真逐字（yrc）恒逐字；lrc 在「初始」面板开了
       强行逐字时走伪逐字（cardForceWord 镜像 + onChanged 热跟随），
       关时逐行——开关切换经 rebuildForForce 重建 DOM 重判。 */
    lyMode = (p.src === "yrc" || (p.src === "lrc" && forceWord)) ? 1 : 0;
    for (var i = 0; i < p.lines.length; i++) {
      var ln = p.lines[i];
      var row = document.createElement("div");
      row.className = "fln";
      var words = [];
      if (lyMode === 1 && ln.w && ln.w.length) {
        for (var w = 0; w < ln.w.length; w++) {
          var sp = document.createElement("span");
          sp.className = "fw";
          sp.appendChild(document.createTextNode(ln.w[w].t));
          var ov = document.createElement("span");
          ov.className = "ov";
          ov.appendChild(document.createTextNode(ln.w[w].t));
          sp.appendChild(ov);
          row.appendChild(sp);
          words.push({ ov: ov, p: -1 });
        }
      } else {
        row.textContent = ln.t || "·";
      }
      if (!ln.t) row.classList.add("gap");
      if (ln.tr) {
        /* v8.3.4 翻译行包 grid 壳：0fr↔1fr 高度过渡替代 display 硬切
           （切行布局零跳变，根治「咯噔」主因）；fsub 本体变内层轨道件 */
        var subw = document.createElement("div");
        subw.className = "fsubw";
        var sub = document.createElement("div");
        sub.className = "fsub";
        sub.textContent = ln.tr;
        subw.appendChild(sub);
        row.appendChild(subw);
      }
      flyrIn.appendChild(row);
      lineEls.push({ el: row, words: words, sung: false, clean: true });
    }
  }

  /* ---------- 逐帧歌词渲染：行切换 + 当前词扫色 + 高光保持 + 暂停淡出 ----------
     v8.2.2 高光保持律（用户实机反馈：唱完的行在下一句开始前高光不得提前
     消失，浮窗与「初始」面板同律）：
     · 当前行扫到 100% 后高光挂住（250ms 自动渐隐废弃）——只有行切换离开
       时才进 done 渐隐（.ov opacity .6s + 行色渐灰）；
     · 间奏（lineIndex=-1）自然流入（上一活动行 === lastLine）：DOM 不动，
       高光挂到下一句开始；seek 跨间奏落入（activeLine ≠ lastLine）：按
       已唱界对账；
     · 行切换/回退：未来行无条件还原未唱态——含曾 done 行（done 移除后
       --p 定格残留必须归零，v8.1.4 clean 标记漏洞修复）；
     · 词扫光写值防抖：进度量化 0.25%，不变不写（暂停帧零样式写入）。 */
  function reconcileLines(active, ref) {
    for (var i = 0; i < lineEls.length; i++) {
      var on = i === active;
      var was = lineEls[i].el.classList.contains("done");
      var done = ref >= 0 && i <= ref && !on;
      lineEls[i].el.classList.toggle("on", on);
      lineEls[i].el.classList.toggle("done", done);
      if (on) {
        lineEls[i].sung = true;
        lineEls[i].clean = false; /* 重新扫光：清定格标记 */
        continue;
      }
      if (done) {
        if (!was) {
          /* 唱过的行定格全亮渐隐；seek 跳中段的未唱行直接灰 */
          if (lineEls[i].sung) { finalizeLine(i); lineEls[i].clean = true; }
          else { restoreLine(i); lineEls[i].clean = true; }
        }
      } else {
        /* 未来行无条件还原未唱态：曾 on 行的扫光残留与曾 done 行的
           定格残留（clean 标记为 true 也不能跳过——类已移除但 --p 还在） */
        if (was || !lineEls[i].clean) restoreLine(i);
        lineEls[i].clean = true;
        lineEls[i].sung = false;
      }
    }
  }
  /* v8.3.3 行界滞回门（上一句模糊「重置感」根治之二）：位置源回跳
     （SW/桥管线延迟、连续回退放行后的软重锚入轨在上游滞后 ~1s 时
     导数变负=显示倒退 ~150ms）会让 align 行号跨界翻转——上一行刚进
     done（blur 0→1.1 在飞）又被重点亮（取消+倒放+重演 = 字面意义的
     模糊重置）。门律：前进即时（零延迟不伤同步/逐行快一拍律不破）；
     后退/间奏类候选须持续 650ms 才采纳（真 seek 回退必然满足，锚点
     噪声 1-3 帧即死）；护航期内或候选出现后位置又硬跳（>2.5s 或
     lastHardAt 300ms 内）= 真 seek 立即放行。 */
  var gPend = null, gPendAt = 0, gPendMs = 0;
  var GATE_MS = 650, GATE_JUMP_MS = 2500, GATE_HARD_MS = 300;
  /* v8.3.4 滚动 target 逐帧追踪：fsubw 高度过渡（0fr↔1fr）期间 offsetHeight/
     offsetTop 连续变化，切行瞬间算一次的 target 是过渡起始值（偏差半行
     翻译高）——追踪窗内每帧重算，transform transition 对小步目标变化
     平滑跟随，收敛于终态 = 翻译展开与滚动同步无跳。560ms 略大于
     fsubw 过渡 380ms。 */
  var lyrTrackUntil = 0, lyrTrackIdx = -1;
  function scrollLyricTo(idx, track) {
    var elc = lineEls[idx].el;
    var target = (flyrIn.parentNode.clientHeight - elc.offsetHeight) / 2 - elc.offsetTop;
    if (target !== lastLyrTy) { lastLyrTy = target; flyrIn.style.transform = "translateY(" + target + "px)"; }
    if (track) { lyrTrackUntil = Date.now() + 560; lyrTrackIdx = idx; }
  }
  function lyricFrame() {
    if (!lineEls.length || !ly.parsed) return;
    var ms = posNow() * 1000;
    /* v8.2.9 行级时钟分离：逐行渲染（lyMode=0）用原始时基（行界快一拍，
       用户反馈「逐行慢了一点」）；逐字扫光保持 -100ms 唱声补偿。 */
    var n = ChuShiLyric.align(ly.parsed, ms, lyMode === 0);
    var gateHold = false;
    if (n.lineIndex !== activeLine) {
      var nowG = Date.now();
      if (gPend !== n.lineIndex) { gPend = n.lineIndex; gPendAt = nowG; gPendMs = ms; }
      var fwd = n.lineIndex > activeLine;
      var bypass = seekGuard || nowG - lastHardAt < GATE_HARD_MS ||
        Math.abs(ms - gPendMs) > GATE_JUMP_MS;
      if (fwd || bypass || nowG - gPendAt >= GATE_MS) {
        gPend = null;                 /* 放行：真值帧进下方切换分支 */
      } else {
        gateHold = true;              /* 压制：本帧维持原判（n 不动，词扫描分支自然跳过） */
      }
    } else {
      gPend = null;
    }
    if (!gateHold && n.lineIndex !== activeLine) {
      if (n.lineIndex < 0) {
        /* 间奏：自然流入（activeLine === lastLine）高光保持不动；
           跨间奏跳入按已唱界对账。activeLine 保持行号（非 -1），
           下一句开始时走正常行切换路径渐灰。 */
        var ref = typeof n.lastLine === "number" && n.lastLine >= 0 ? n.lastLine : -1;
        if (ref !== activeLine) {
          reconcileLines(-1, ref);
          /* v8.2.8 间奏滚动跟进：seek 跨间奏落入时歌词区立即滚到已唱界
             行——旧版停在旧滚动位直到下一句开始 = 长间奏歌词区完全错位
             （跳转后歌词对不上、逐行尤严重的根因）。自然流入不滚。 */
          if (ref >= 0 && ref < lineEls.length) {
            scrollLyricTo(ref, true); /* 旧行 fsub 收起同样改布局，一并追踪 */
          }
        }
        /* ref === activeLine：什么都不动——高光挂住等下一句 */
      } else {
        activeLine = n.lineIndex;
        reconcileLines(activeLine, activeLine);
        scrollLyricTo(activeLine, true);
      }
    }
    /* fsubw 高度过渡追踪窗：每帧重算 target（小步目标变化由 transform
       transition 平滑跟随，终态收敛精确居中） */
    if (lyrTrackUntil) {
      if (Date.now() >= lyrTrackUntil || lyrTrackIdx < 0 || lyrTrackIdx >= lineEls.length) { lyrTrackUntil = 0; }
      else scrollLyricTo(lyrTrackIdx, false);
    }
    /* v8.2.4 高光保持补门（面板同律）：n.lineIndex === activeLine 才写词——
       真 yrc 行尾+200ms 进间奏（wordIndex=-1），旧版把全词 p 重算 0 =
       扫光塌零「播放完动画就结束高亮」；间奏自然流入期不写词，挂 100%
       到下一行开始才随 done 渐隐。 */
    if (lyMode === 1 && activeLine >= 0 && activeLine < lineEls.length && n.lineIndex === activeLine) {
      var ws = lineEls[activeLine].words;
      for (var j = 0; j < ws.length; j++) {
        var pp = j < n.wordIndex ? 1 : j > n.wordIndex ? 0 : (n.wordIndex >= 0 ? n.wordProgress : 0);
        var q = Math.round(pp * 400) / 400; /* 0.25% 量化：不变不写 */
        if (ws[j].p !== q) {
          ws[j].p = q;
          ws[j].ov.style.setProperty("--p", (q * 100).toFixed(2) + "%");
        }
      }
    }
    var playing = effPlaying();
    if (prevLyrPlaying !== playing) {
      prevLyrPlaying = playing;
      flyrIn.style.opacity = playing ? "1" : "0.38";
    }
  }
  function finalizeLine(idx) {
    var ws = lineEls[idx].words;
    for (var j = 0; j < ws.length; j++) {
      ws[j].p = 1;
      ws[j].ov.style.setProperty("--p", "100%");
    }
  }
  function restoreLine(idx) {
    var ws = lineEls[idx].words;
    for (var j = 0; j < ws.length; j++) {
      ws[j].p = 0;
      ws[j].ov.style.setProperty("--p", "0%");
    }
  }

  /* ---------- 交互绑定 ---------- */
  function bindPlay(btn) {
    el(btn).addEventListener("click", function () {
      var cur = effPlaying();
      optP = !cur; optAt = Date.now();
      applyVis();
      send("toggle", undefined);
    });
  }
  bindPlay("play"); bindPlay("fplay");
  el("prev").addEventListener("click", function () { send("prev", undefined); });
  el("next").addEventListener("click", function () { send("next", undefined); });
  el("fprev").addEventListener("click", function () { send("prev", undefined); });
  el("fnext").addEventListener("click", function () { send("next", undefined); });
  el("miniCover").addEventListener("click", function () { setMode("cover"); });
  el("miniFull").addEventListener("click", function () { setMode("full"); });
  el("fullCover").addEventListener("click", function () { setMode("cover"); });
  el("fullMini").addEventListener("click", function () { setMode("mini"); });
  coverEl.addEventListener("click", function () {
    if (Date.now() - coverClickBlock < 350) return; /* 封面拖动后的误触 click */
    setMode("mini");
  });
  /* 标准态进度条：点按 → 完全体（不跳回「初始」）；完全体进度条：点按 → seek */
  el("rail").addEventListener("click", function (e) {
    e.stopPropagation();
    setMode("full");
  });
  el("frail").addEventListener("click", function (e) {
    e.stopPropagation();
    if (!track || !(track.duration > 0)) return;
    var rect = el("frail").getBoundingClientRect();
    var r = (e.clientX - rect.left) / Math.max(1, rect.width);
    r = Math.min(1, Math.max(0, r));
    send("seek", Math.round(r * track.duration));
  });
  /* 右键隐藏已退役（v8.2.9 用户指令：取消右键隐藏浮窗的逻辑，全局开关在
     「初始」面板；此处不再拦截右键菜单，交还浏览器默认行为） */
  window.addEventListener("resize", applyPos);

  /* ---------- rAF 主循环：进度插值 + 完全体歌词帧 + 辉光律动 ----------
     v8.2.6 休眠改造（5070 卡顿根治①）：循环不再无条件永转——
     needFrame() 判定「还有活干」才续帧：
     · 页面 hidden（切后台/最小化）→ 立睡（visibilitychange 唤醒）；
     · 无曲目 → 睡（state 消息唤醒）；
     · 频谱活动（spec.on && playing）→ rAF 60fps（辉光包络要顺滑）；
     · 完全体 → rAF（逐字扫光逐帧）；
     · mini 走针 / cover 静置 → 200ms 定时节拍（1s 变一次的字符串够用）；
     · 辉光衰减尾（envBass>0.012）→ 续帧到归零再睡（辉光不冻半透明）。
     后台标签同时撤频谱订阅（②）——三件联动把「N 标签 × 60fps rAF +
     N × 20msg/s spec 扇出」的 renderer 唤醒风暴整体清零。 */
  var lastFillW = "";
  var lastTcur = "", lastTdur = "";
  var rafId = 0, tickTimer = 0;
  /* ---------- v8.2.8 律动引擎（去框化·全频段细腻律） ----------
     用户澄清：「细节」= 律动覆盖高中低音且细腻，不是加方框（v8.2.7 的
     .gring 细节环废弃——方框太丑）。三轴全部融入封面本体 filter 与辉光
     本体：低音 = 提亮 + 辉光主推 + 对比微脉冲；中频 = 亮度微调 + 辉光
     次推 + 光晕尺寸；高频 = 饱和脉冲 + 辉光点缀。pow 0.85 曲线提升小
     信号可见度；分轴攻放（中高频攻快放快 = 跟手细腻，低音慢放 = 鼓点
     余韵）。写值防抖：字符串不变不写；非当前态/静默 → 交还样式表。
     数据面：SW 30Hz 原始帧（v8.2.8），包络在卡侧。 */
  var COVS = {
    mini:  { img: pic,  glow: glow,  on: 0, lf: "", lo: "", lt: "" },
    full:  { img: fpic, glow: glow2, on: 0, lf: "", lo: "", lt: "" },
    cover: { img: cpic, glow: cglow, on: 0, lf: "", lo: "", lt: "" }
  };
  function specTgt() {
    /* v8.2.9 律动总开关：关 = 不产目标值（三轴自然衰减到 0，辉光归还样式表） */
    if (!glowEnabled || !lastSpec.on || !effPlaying()) return null;
    var bands = lastSpec.bands, m = 0, h = 0, i;
    if (bands && bands.length) {
      if (bands.length >= 100) {
        /* v8.2.9 128 段·实际映射律（低频侧线性化 段k≈bin k+2）：
           中 9..84 ≈ 250Hz~2kHz，高 85+ ≈ 2k~16kHz（对数区）；
           低音轴直接用 native bass（0..6 段分区带权 47~211Hz）。 */
        for (i = 9; i <= 84 && i < bands.length; i++) m += Number(bands[i]) || 0;
        m /= 76;
        var hn = 0;
        for (i = 85; i < bands.length; i++) { h += Number(bands[i]) || 0; hn++; }
        if (hn > 0) h /= hn;
      } else {
        /* 旧 native 16 段语义（兼容窗口） */
        for (i = 3; i <= 9; i++) m += Number(bands[i]) || 0;
        m /= 7;
        for (i = 10; i < 16; i++) h += Number(bands[i]) || 0;
        h /= 6;
      }
    }
    return { b: Number(lastSpec.bass) || 0, m: m, h: h };
  }
  function stepEnv() {
    var t = specTgt();
    var tb = t ? t.b : 0, tm = t ? t.m : 0, th = t ? t.h : 0;
    envB += (tb - envB) * (tb > envB ? 0.62 : 0.14);
    envM += (tm - envM) * (tm > envM ? 0.68 : 0.20);
    envH += (th - envH) * (th > envH ? 0.72 : 0.24);
    if (envB < 0.005) envB = 0;
    if (envM < 0.006) envM = 0;
    if (envH < 0.006) envH = 0;
    /* v8.3.1 自适应归一化（AGC）——用户实机反馈：部分歌（《不凡》等低音
       能量偏小的曲子）律动不明显。峰值跟随器分轴记天花板：快攻慢放
       （攻=瞬间、放=每帧 ×0.998+线性微降，半衰期 ~8s，地板 0.12 防静音
       段放大底噪）——整曲电平低 → 天花板随之下移 → 显示值被拉回满幅
       可见区间；响歌天花板贴真实峰值 → 动态对比保持。换歌自动重适应。 */
    pkB = Math.max(envB, pkB * 0.998 - 0.0004);
    pkM = Math.max(envM, pkM * 0.998 - 0.0004);
    pkH = Math.max(envH, pkH * 0.998 - 0.0004);
    if (pkB < 0.12) pkB = 0.12;
    if (pkM < 0.12) pkM = 0.12;
    if (pkH < 0.12) pkH = 0.12;
  }
  /* 显示值 = 包络 / 分轴天花板（0..1 夹紧）——响度归一，弱歌不再隐形 */
  function envNorm() {
    return {
      b: Math.min(1, envB / pkB),
      m: Math.min(1, envM / pkM),
      h: Math.min(1, envH / pkH)
    };
  }
  /* v8.3.1 高光渐入因子：形变落地后 ~480ms 从 0 平滑升到 1（smoothstep） */
  function glowRamp() {
    if (!glowRampAt) return 1;
    var el = Date.now() - glowRampAt;
    if (el >= 480) { glowRampAt = 0; return 1; }
    if (el <= 0) return 0;
    var k = el / 480;
    return k * k * (3 - 2 * k);
  }
  function covClear(c) {
    c.on = 0; c.lo = c.lt = "";
    c.glow.style.opacity = "";
    c.glow.style.transform = "";
  }
  function paintGlow() {
    var act = envB > 0.012 || envM > 0.02 || envH > 0.02;
    var n = envNorm();
    var ramp = glowRamp();
    for (var k in COVS) {
      var c = COVS[k];
      if (k !== mode || !act || ramp === 0) { if (c.on) covClear(c); continue; }
      /* v8.3.3 高光归位律（用户：不要给封面加高光，高光就在封面底下）：
         封面本体 brightness/saturate/contrast 滤镜整体退役（v8.2.7
         「封面提亮」路线废弃）——能量全部改走辉光本体（封面背后
         .glow 层，z-index:0 被 img 压住，光环只从四周晕出）：
         不透明度增益拉满（低音主推 0.68→0.85，基线 0.20→0.28）+
         呼吸幅度加大（scale 0.06→0.08）；封面图本体恒定不动。 */
      var pb = Math.pow(n.b, 0.75), pm = Math.pow(n.m, 0.75), ph = Math.pow(n.h, 0.75);
      var go = Math.min(1, (0.28 + pb * 0.85 + pm * 0.34 + ph * 0.16) * ramp).toFixed(3);
      var gt = "scale(" + (1 + (n.b * 0.08 + n.m * 0.038 + n.h * 0.02) * ramp).toFixed(4) + ")";
      if (go !== c.lo) { c.lo = go; c.glow.style.opacity = go; }
      if (gt !== c.lt) { c.lt = gt; c.glow.style.transform = gt; }
      c.on = 1;
    }
  }
  function loopBody() {
    if (track) {
      var dur = track.duration || 0;
      var pr = dur > 0 ? Math.min(1, posNow() / dur) : 0;
      var w = (pr * 100).toFixed(2) + "%";
      if (w !== lastFillW) {
        lastFillW = w;
        fill.style.width = w;
        ffill.style.width = w;
      }
      if (mode === "full") {
        /* 写值防抖：fmt 每秒才变一次，字符串比对代替每帧 textContent 写 */
        var tc = fmt(posNow());
        if (tc !== lastTcur) { lastTcur = tc; tcur.textContent = tc; mtm.textContent = tc; }
        var td = dur > 0 ? fmt(dur) : "--:--";
        if (td !== lastTdur) { lastTdur = td; tdur.textContent = td; }
        lyricFrame();
      } else if (mode === "mini") {
        /* v8.2.3b 顶带时间在 mini 也走针（空带填充修复的本体——不然带左
           时间永远冻结在 0:00，空带照旧） */
        var tc = fmt(posNow());
        if (tc !== lastTcur) { lastTcur = tc; mtm.textContent = tc; }
      }
    }
    stepEnv();
    paintGlow();
    if (dlOn) dlFrame(); /* v8.7.16：全局歌词逐帧/逐拍渲染（needFrame 保底供拍） */
    /* 播放态图标真值回收：真值到达路径 = onState→applyVis→effPlaying 内对齐
       即清窗；此处只兜底硬上限到期那一刻的重绘 */
    if (optAt && Date.now() - optAt >= OPT_MAX) { applyVis(); }
  }
  function needFrame() {
    if (document.visibilityState !== "visible") return false;
    if (lastSpec.on && effPlaying()) return true;   /* 辉光律动中 */
    if (envB > 0.012 || envM > 0.02 || envH > 0.02) return true; /* 衰减尾（三轴） */
    if (!track) return false;
    if (dlOn && track.playing) return true; /* v8.7.16：全局歌词走针/扫光需求（行界 200ms 拍兜底） */
    if (mode === "full") return true;               /* 歌词逐字 + 走针 */
    if (mode === "mini") return !!track.playing || !!optAt; /* 走针/乐观窗 */
    return !!optAt;                                 /* cover：仅乐观窗 */
  }
  function schedule() {
    /* 完全体逐字/辉光活动/衰减尾 → rAF（60fps 顺滑）；纯走针 → 200ms 节拍
       v8.7.16：全局歌词词模式播放中同享 rAF（扫光逐帧），行模式走 200ms 拍 */
    if (mode === "full" || (dlOn && dlWordMode && effPlaying()) || (lastSpec.on && effPlaying()) || envB > 0.012 || envM > 0.02 || envH > 0.02) {
      rafId = requestAnimationFrame(frame);
    } else {
      tickTimer = setTimeout(tick, 200);
    }
  }
  function frame() { rafId = 0; loopBody(); if (needFrame()) schedule(); }
  function tick() { tickTimer = 0; loopBody(); if (needFrame()) schedule(); }
  function sleepNow() {
    if (rafId) { cancelAnimationFrame(rafId); rafId = 0; }
    if (tickTimer) { clearTimeout(tickTimer); tickTimer = 0; }
  }
  function wake() {
    if (!cardEnabled && !dlOn) return; /* v8.7.16：全局歌词会话同样可唤醒 */
    if (document.visibilityState !== "visible") return;
    if (rafId || tickTimer) return; /* 已醒：下一拍自会按 needFrame 重估 */
    if (needFrame()) schedule();
  }
  /* v8.3.0：可见性翻转 = 频谱订阅 + 渲染循环 双联开关（vis 上报退役——
     state 轮询常开，切歌真值永远可达，见文件头 ②） */
  document.addEventListener("visibilitychange", function () {
    var vis = document.visibilityState === "visible";
    try {
      if (port) port.postMessage({ type: "spec", on: specMsgOn() });
    } catch (e) { /* 断线事件接管 */ }
    if (vis) wake(); else sleepNow();
  });

  /* ---------- 启动（v8.2.9：全局开关门控，替代旧站点隐藏） ---------- */
  initCard(); /* cardEnabled 默认 true；关态下由 storage 回调后再启动 */
})();
