ChuShi SMTC engine v5.0.0 manual fallback.
Double-click Start-Engine.bat to start the engine.
ASCII + CRLF by contract.
