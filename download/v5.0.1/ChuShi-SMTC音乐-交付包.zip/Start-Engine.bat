@echo off
rem ChuShi SMTC engine manual start (fallback when the manager plugin
rem cannot spawn processes; security software may block automatic starts)
taskkill /F /IM powershell.exe /FI "WINDOWTITLE eq ChuShiSmtcEngine*" >nul 2>&1
start "ChuShiSmtcEngine" /MIN powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0chushi-smtc-engine.ps1"
echo ChuShi SMTC engine started (window is hidden by design).
echo Check the ChuShi new tab page: it should connect within a few seconds.
pause
